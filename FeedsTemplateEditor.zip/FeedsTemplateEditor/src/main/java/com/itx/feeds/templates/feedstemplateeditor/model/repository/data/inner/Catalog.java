package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

// TODO: Auto-generated Javadoc
/**
 * The Class Catalog.
 */
public class Catalog {

    /** The id. */
    private int id;

    /** The identifier. */
    private String identifier;

    /**
     * Instantiates a new catalog.
     *
     * @param id
     *            the id
     * @param identifier
     *            the identifier
     */
    public Catalog(int id, String identifier) {
        super();
        this.id = id;
        this.identifier = identifier;
    }

    /**
     * Instantiates a new catalog.
     */
    public Catalog() {
        super();
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public int getId() {
        return this.id;
    }

    /**
     * Sets the id.
     *
     * @param id
     *            the new id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the identifier.
     *
     * @return the identifier
     */
    public String getIdentifier() {
        return this.identifier;
    }

    /**
     * Sets the identifier.
     *
     * @param identifier
     *            the new identifier
     */
    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

}
