package com.itx.feeds.templates.feedstemplateeditor.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

// TODO: Auto-generated Javadoc
/**
 * The Class ColorPartNumberInfo.
 *
 * @author LUISVPI
 */
public class ColorPartNumberInfo extends ProductPartNumberInfo {

    /** The empty partnumber. */
    public static String EMPTY_PARTNUMBER = "00000000000-V2000";

    /** The pattern. */
    public static Pattern pattern = Pattern.compile("(\\d)(\\d{4})(\\d{3})(\\d{3})-([VI])(\\d{4})");

    /** The color. */
    protected final Integer color;

    /**
     * Instantiates a new color part number info.
     *
     * @param section
     *            the section
     * @param model
     *            the model
     * @param quality
     *            the quality
     * @param color
     *            the color
     * @param season
     *            the season
     * @param year
     *            the year
     */
    protected ColorPartNumberInfo(Integer section, Integer model, Integer quality, Integer color, String season,
            Integer year) {
        super(section, model, quality, season, year);
        this.color = color;
    }

    /**
     * Gets the color.
     *
     * @return the color
     */
    public Integer getColor() {
        return color;
    }

    /**
     * Gets the format color.
     *
     * @return the format color
     */
    public String getFormatColor() {
        return String.format("%03d", Integer.parseInt(color.toString()));
    }

    /**
     * Builds the.
     *
     * @param partNumber
     *            the part number
     * @return the color part number info
     */
    public static ColorPartNumberInfo build(String partNumber) {
        Matcher m = pattern.matcher(partNumber);
        if (!m.matches()) {
            return null;
        }
        return new ColorPartNumberInfo(Integer.valueOf(m.group(1)), Integer.valueOf(m.group(2)),
                Integer.valueOf(m.group(3)), Integer.valueOf(m.group(4)), m.group(5), Integer.valueOf(m.group(6)));
    }

    /**
     * To color part number.
     *
     * @return the string
     */
    public String toColorPartNumber() {
        return String.format("%01d%04d%03d%03d-%s%04d", section, model, quality, color, season, year);
    }

}