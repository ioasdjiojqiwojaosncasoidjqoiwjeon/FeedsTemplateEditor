package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

/**
 * The Class MocaColor.
 */
public class MocaStoreColor {

    /** The id color. */
    private String idColor;

    /** The is continuity. */
    private Boolean isContinuity;

    /**
     * Instantiates a new moca color.
     *
     * @param idColor
     *            the id color
     * @param isContinuity
     *            the is continuity
     */
    public MocaStoreColor(String idColor, Boolean isContinuity) {
        super();
        this.idColor = idColor;
        this.isContinuity = isContinuity;
    }

    /**
     * Instantiates a new moca color.
     */
    public MocaStoreColor() {
        super();
    }

    /**
     * Gets the id color.
     *
     * @return the id color
     */
    public String getIdColor() {
        return this.idColor;
    }

    /**
     * Sets the id color.
     *
     * @param idColor
     *            the new id color
     */
    public void setIdColor(String idColor) {
        this.idColor = idColor;
    }

    /**
     * Gets the checks if is continuity.
     *
     * @return the checks if is continuity
     */
    public Boolean getIsContinuity() {
        return this.isContinuity;
    }

    /**
     * Sets the checks if is continuity.
     *
     * @param isContinuity
     *            the new checks if is continuity
     */
    public void setIsContinuity(Boolean isContinuity) {
        this.isContinuity = isContinuity;
    }

}
