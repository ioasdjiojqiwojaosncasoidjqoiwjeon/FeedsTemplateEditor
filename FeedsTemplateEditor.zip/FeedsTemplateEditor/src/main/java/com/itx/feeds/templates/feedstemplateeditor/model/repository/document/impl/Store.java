package com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl.StoreData;

// TODO: Auto-generated Javadoc
/**
 * The Class Store.
 */
public class Store extends AbstractBrandedVersionedDocumentImpl<StoreData> {

    /** The store id. */
    private Integer storeId;

    /**
     * Instantiates a new store.
     *
     * @param data
     *            the data
     * @param feedsVersion
     *            the feeds version
     * @param brandId
     *            the brand id
     * @param storeId
     *            the store id
     */
    public Store(StoreData data, long feedsVersion, Integer brandId, Integer storeId) {
        super(data, feedsVersion, brandId);
        this.storeId = storeId;
    }

    /**
     * Instantiates a new store.
     */
    public Store() {
        super();
    }

    /**
     * Gets the store id.
     *
     * @return the store id
     */
    public Integer getStoreId() {
        return this.storeId;
    }

    /**
     * Sets the store id.
     *
     * @param storeId
     *            the new store id
     */
    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

}
