package com.itx.feeds.templates.feedstemplateeditor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.javatuples.Quartet;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.itx.feeds.templates.feedstemplateeditor.export.ConfigurationUtils;
import com.itx.feeds.templates.feedstemplateeditor.model.ExportableModel;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Category;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.StoreCatalogLanguageCategories;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.SupportedLanguage;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.Brand;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.CategoriesList;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.Configuration;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.Moca;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.MocaI18n;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.MocaStore;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.Store;

public class ModelLoader {

	private static final ObjectMapper objectMapper = new ObjectMapper();

	public ExportableModel getExportableModelFromFiles(List<File> files) {

		Optional<Brand> brandOpt = getModelEntityByFile(files, Brand.class);

		Optional<Store> storeOpt = getModelEntityByFile(files, Store.class);

		Optional<Moca> mocaOpt = getModelEntityByFile(files, Moca.class);

		Optional<CategoriesList> categoriesListOpt = getModelEntityByFile(files, CategoriesList.class);

		Optional<List<Configuration>> configurationOpt = getModelEntityListByFile(files, Configuration.class);

		final Map<Quartet<String, Integer, Integer, Integer>, String> configurationMap;
		if (configurationOpt.isPresent()) {
			configurationMap = ConfigurationUtils.loadConfigMap(configurationOpt.get(), brandOpt.get().getBrandId());
		} else {
			configurationMap = new HashMap<>();
		}

		SortedMap<Quartet<Integer, Integer, Integer, Long>, Category> mapLanguageCategories;
		if (categoriesListOpt.isPresent()) {
			mapLanguageCategories = getMapLanguageCategoriesByCategoriesList(Arrays.asList(categoriesListOpt.get()));
		} else {
			mapLanguageCategories = new TreeMap<>();
		}

		MocaStore mocaStore;
		if (mocaOpt.isPresent()) {
			mocaStore = mocaOpt.get().getMocaStoreList().stream().findFirst().orElse(null);
		} else {
			mocaStore = null;
		}

		List<MocaStore> mocaStores;
		if (mocaOpt.isPresent()) {
			mocaStores = mocaOpt.get().getMocaStoreList();
		} else {
			mocaStores = null;
		}

		MocaI18n mocaI18n;
		if (mocaOpt.isPresent()) {
			mocaI18n = mocaOpt.get().getMocaStoreList().stream()
					.map(mocaStoreRead -> mocaStoreRead.getMocaI18nList().stream().findFirst().get())
					.collect(Collectors.toList()).stream().findFirst().orElse(null);
		} else {
			mocaI18n = null;
		}

		List<MocaI18n> mocaI18ns;
		if (mocaI18n != null) {
			mocaI18ns = Arrays.asList(mocaI18n);
		} else {
			mocaI18ns = null;
		}

		SupportedLanguage language;
		if (storeOpt.isPresent()) {
			language = storeOpt.get().getData().getSupportedLanguage().stream().findFirst().orElse(null);
		} else {
			language = null;
		}

		Map<Integer, Store> storesMap = Arrays.asList(storeOpt.orElse(null)).stream().filter(store -> store != null)
				.collect(Collectors.toMap(Store::getStoreId, Function.identity()));

		return new ExportableModel(brandOpt.orElse(null), mocaOpt.orElse(null), mocaStore, mocaI18n, mocaI18ns,
				mocaStores, storesMap, storeOpt.orElse(null), language, mapLanguageCategories, configurationMap);

	}

	private <E> Optional<List<E>> getModelEntityListByFile(List<File> files, Class<E> type) {
		final Optional<File> entityFile = files.stream().filter(file -> file.getName().contains(type.getSimpleName()))
				.findFirst();
		 CollectionType listType = 
			      objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, type);
		if (entityFile.isPresent()) {
			try {
				return Optional.of(objectMapper.readValue(entityFile.get(), listType));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return Optional.empty();
	}

	private <E> Optional<E> getModelEntityByFile(List<File> files, Class<E> type) {
		final Optional<File> entityFile = files.stream().filter(file -> file.getName().contains(type.getSimpleName()))
				.findFirst();
		if (entityFile.isPresent()) {
			try {
				return Optional.of(objectMapper.readValue(entityFile.get(), type));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return Optional.empty();
	}

	private SortedMap<Quartet<Integer, Integer, Integer, Long>, Category> getMapLanguageCategoriesByCategoriesList(
			List<CategoriesList> categoriesList) {
		SortedMap<Quartet<Integer, Integer, Integer, Long>, Category> mapLanguageCategories = new TreeMap<Quartet<Integer, Integer, Integer, Long>, Category>();

		for (CategoriesList categoryList : categoriesList) {
			for (StoreCatalogLanguageCategories storeCatalogCategories : categoryList.getData()
					.getStoreCatalogLanguageCategories()) {

				for (Category category : storeCatalogCategories.getCategories()) {
					category.setParent(null);
					Quartet<Integer, Integer, Integer, Long> languageStoreCatalogCategory = new Quartet<Integer, Integer, Integer, Long>(
							categoryList.getLanguageId(), categoryList.getStoreId(), categoryList.getCatalogId(),
							category.getIdCategory());
					mapLanguageCategories.put(languageStoreCatalogCategory, category);

					setMapLanguangeCategoriesByLanguageStoreCategory(categoryList.getLanguageId(),
							categoryList.getStoreId(), categoryList.getCatalogId(), category, mapLanguageCategories);
				}
			}
		}

		return mapLanguageCategories;
	}

	private void setMapLanguangeCategoriesByLanguageStoreCategory(Integer languageId, Integer storeId,
			Integer catalogId, Category categoryParent,
			SortedMap<Quartet<Integer, Integer, Integer, Long>, Category> mapLanguageCategories) {

		if (categoryParent.getSubcategories() != null) {
			for (Category category : categoryParent.getSubcategories()) {

				Quartet<Integer, Integer, Integer, Long> languageStoreCategory = new Quartet<Integer, Integer, Integer, Long>(
						languageId, storeId, catalogId, category.getIdCategory());

				category.setParent(categoryParent);
				mapLanguageCategories.put(languageStoreCategory, category);

				if (category.getSubcategories() != null) {
					setMapLanguangeCategoriesByLanguageStoreCategory(languageId, storeId, catalogId, category,
							mapLanguageCategories);
				}
			}
		}
	}

}
