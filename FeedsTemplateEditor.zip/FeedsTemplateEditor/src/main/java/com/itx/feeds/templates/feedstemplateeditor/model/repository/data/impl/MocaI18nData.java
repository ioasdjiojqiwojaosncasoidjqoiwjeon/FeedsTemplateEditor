package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl;

import java.util.List;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.MocaI18nAttribute;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.MocaI18nCategory;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.MocaI18nColor;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.MocaI18nSize;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Tag;


// TODO: Auto-generated Javadoc
/**
 * The Class MocaI18nData.
 */
public class MocaI18nData extends AbstractDocumentDataImpl {

    /** The name. */
    private String name;

    /** The product url. */
    private String productUrl;

    /** The keywords. */
    private String keywords;

    /** The family. */
    private String family;

    /** The subfamily. */
    private String subfamily;

    /** The description. */
    private String description;

    /** The long description. */
    private String longDescription;

    /** The tags. */
    private List<Tag> tags;

    /** The MocaI18nAttribute. */
    private List<MocaI18nAttribute> attributes;

    /** The section. */
    private String section;

    /** The color. */
    private List<MocaI18nColor> color;

    /** The size. */
    private List<MocaI18nSize> size;

    /** The section name. */
    private String sectionName;

    /** The family name. */
    private String familyName;

    /** The subfamily name. */
    private String subfamilyName;

    /** The related categories. */
    private List<MocaI18nCategory> relatedCategories;

    /**
     * Instantiates a new moca i18n data.
     *
     * @param name
     *            the name
     * @param keywords
     *            the keywords
     * @param family
     *            the family
     * @param subfamily
     *            the subfamily
     * @param description
     *            the description
     * @param longDescription
     *            the long description
     * @param tags
     *            the tags
     * @param section
     *            the section
     * @param color
     *            the color
     * @param size
     *            the size
     * @param sectionName
     *            the section name
     * @param familyName
     *            the family name
     * @param subfamilyName
     *            the subfamily name
     * @param relatedCategories
     *            the related categories
     */
    public MocaI18nData(String name, String keywords, String family, String subfamily, String description,
            String longDescription, List<Tag> tags, String section, List<MocaI18nColor> color, List<MocaI18nSize> size,
            String sectionName, String familyName, String subfamilyName, List<MocaI18nCategory> relatedCategories) {
        super();
        this.name = name;
        this.keywords = keywords;
        this.family = family;
        this.subfamily = subfamily;
        this.description = description;
        this.longDescription = longDescription;
        this.tags = tags;
        this.section = section;
        this.color = color;
        this.size = size;
        this.sectionName = sectionName;
        this.familyName = familyName;
        this.subfamilyName = subfamilyName;
    }

    /**
     * Instantiates a new moca i18n data.
     */
    public MocaI18nData() {
        super();
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the name.
     *
     * @param name
     *            the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the product url.
     *
     * @return the product url
     */
    public String getProductUrl() {
        return productUrl;
    }

    /**
     * Sets the product url.
     *
     * @param productUrl
     *            the new product url
     */
    public void setProductUrl(String productUrl) {
        this.productUrl = productUrl;
    }

    /**
     * Gets the keywords.
     *
     * @return the keywords
     */
    public String getKeywords() {
        return this.keywords;
    }

    /**
     * Sets the keywords.
     *
     * @param keywords
     *            the new keywords
     */
    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    /**
     * Gets the family.
     *
     * @return the family
     */
    public String getFamily() {
        return this.family;
    }

    /**
     * Sets the family.
     *
     * @param family
     *            the new family
     */
    public void setFamily(String family) {
        this.family = family;
    }

    /**
     * Gets the subfamily.
     *
     * @return the subfamily
     */
    public String getSubfamily() {
        return this.subfamily;
    }

    /**
     * Sets the subfamily.
     *
     * @param subfamily
     *            the new subfamily
     */
    public void setSubfamily(String subfamily) {
        this.subfamily = subfamily;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Sets the description.
     *
     * @param description
     *            the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets the long description.
     *
     * @return the long description
     */
    public String getLongDescription() {
        return this.longDescription;
    }

    /**
     * Sets the long description.
     *
     * @param longDescription
     *            the new long description
     */
    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    /**
     * Gets the tags.
     *
     * @return the tags
     */
    public List<Tag> getTags() {
        return this.tags;
    }

    /**
     * Sets the tags.
     *
     * @param tags
     *            the new tags
     */
    public void setTags(List<Tag> tags) {
        this.tags = tags;
    }

    /**
     * @return the attributes
     */
    public List<MocaI18nAttribute> getAttributes() {
        return attributes;
    }

    /**
     * @param attributes
     *            the attributes to set
     */
    public void setAttributes(List<MocaI18nAttribute> attributes) {
        this.attributes = attributes;
    }

    /**
     * Gets the section.
     *
     * @return the section
     */
    public String getSection() {
        return this.section;
    }

    /**
     * Sets the section.
     *
     * @param section
     *            the new section
     */
    public void setSection(String section) {
        this.section = section;
    }

    /**
     * Gets the color.
     *
     * @return the color
     */
    public List<MocaI18nColor> getColor() {
        return this.color;
    }

    /**
     * Sets the color.
     *
     * @param color
     *            the new color
     */
    public void setColor(List<MocaI18nColor> color) {
        this.color = color;
    }

    /**
     * Gets the size.
     *
     * @return the size
     */
    public List<MocaI18nSize> getSize() {
        return this.size;
    }

    /**
     * Sets the size.
     *
     * @param size
     *            the new size
     */
    public void setSize(List<MocaI18nSize> size) {
        this.size = size;
    }

    /**
     * Gets the section name.
     *
     * @return the section name
     */
    public String getSectionName() {
        return this.sectionName;
    }

    /**
     * Sets the section name.
     *
     * @param sectionName
     *            the new section name
     */
    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    /**
     * Gets the family name.
     *
     * @return the family name
     */
    public String getFamilyName() {
        return this.familyName;
    }

    /**
     * Sets the family name.
     *
     * @param familyName
     *            the new family name
     */
    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    /**
     * Gets the subfamily name.
     *
     * @return the subfamily name
     */
    public String getSubfamilyName() {
        return this.subfamilyName;
    }

    /**
     * Sets the subfamily name.
     *
     * @param subfamilyName
     *            the new subfamily name
     */
    public void setSubfamilyName(String subfamilyName) {
        this.subfamilyName = subfamilyName;
    }

    /**
     * Gets the related categories.
     *
     * @return the related categories
     */
    public List<MocaI18nCategory> getRelatedCategories() {
        return relatedCategories;
    }

    /**
     * Sets the related categories.
     *
     * @param relatedCategories
     *            the new related categories
     */
    public void setRelatedCategories(List<MocaI18nCategory> relatedCategories) {
        this.relatedCategories = relatedCategories;
    }

}
