package com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl.TemplateContentData;

/**
 * The Class Template.
 */
public class TemplateContent extends AbstractDocumentImpl<TemplateContentData> {

    /** The templateName. */
    private String templateName;

    /**
     * Instantiates a new configuration.
     *
     * @param data
     *            the data
     * @param templateName
     *            the key
     */
    public TemplateContent(TemplateContentData data, String templateName) {
        super(data);
        this.templateName = templateName;
    }

    /**
     * Instantiates a new Template.
     */
    public TemplateContent() {
        super();
    }

    /**
     * Gets the templateName.
     *
     * @return the templateName
     */
    public String getTemplateName() {
        return templateName;
    }

    /**
     * Sets the templateName.
     *
     * @param templateName
     *            the new templateName
     */
    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

}
