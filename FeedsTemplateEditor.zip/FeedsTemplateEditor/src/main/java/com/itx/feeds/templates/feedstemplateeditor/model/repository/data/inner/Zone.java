package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class Zone.
 */
public class Zone {

    /** The zone. */
    private String zone;

    /** The zone name. */
    private String zoneName;

    /** The composition. */
    private List<Composition> composition;

    /**
     * Instantiates a new zone.
     *
     * @param zone
     *            the zone
     * @param zoneName
     *            the zone name
     * @param composition
     *            the composition
     */
    public Zone(String zone, String zoneName, List<Composition> composition) {
        super();
        this.zone = zone;
        this.zoneName = zoneName;
        this.composition = composition;
    }

    /**
     * Instantiates a new zone.
     */
    public Zone() {
        super();
    }

    /**
     * Gets the zone.
     *
     * @return the zone
     */
    public String getZone() {
        return this.zone;
    }

    /**
     * Sets the zone.
     *
     * @param zone
     *            the new zone
     */
    public void setZone(String zone) {
        this.zone = zone;
    }

    /**
     * Gets the zone name.
     *
     * @return the zone name
     */
    public String getZoneName() {
        return this.zoneName;
    }

    /**
     * Sets the zone name.
     *
     * @param zoneName
     *            the new zone name
     */
    public void setZoneName(String zoneName) {
        this.zoneName = zoneName;
    }

    /**
     * Gets the composition.
     *
     * @return the composition
     */
    public List<Composition> getComposition() {
        return this.composition;
    }

    /**
     * Sets the composition.
     *
     * @param composition
     *            the new composition
     */
    public void setComposition(List<Composition> composition) {
        this.composition = composition;
    }

}
