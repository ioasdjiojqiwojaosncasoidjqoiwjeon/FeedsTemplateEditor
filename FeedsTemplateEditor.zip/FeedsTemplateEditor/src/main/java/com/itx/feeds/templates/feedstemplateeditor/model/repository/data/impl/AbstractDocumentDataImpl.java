
package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.AbstractDocumentData;

/**
 * The Class AbstractDocumentDataImpl.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class AbstractDocumentDataImpl implements AbstractDocumentData {

}
