package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class Location.
 */
public class Location {

    /** The media locations. */
    private List<String> mediaLocations;

    /** The location. */
    private String location;

    /**
     * Instantiates a new location.
     *
     * @param mediaLocations
     *            the media locations
     * @param location
     *            the location
     */
    public Location(List<String> mediaLocations, String location) {
        super();
        this.mediaLocations = mediaLocations;
        this.location = location;
    }

    /**
     * Instantiates a new location.
     */
    public Location() {
        super();
    }

    /**
     * Gets the media locations.
     *
     * @return the media locations
     */
    public List<String> getMediaLocations() {
        return this.mediaLocations;
    }

    /**
     * Sets the media locations.
     *
     * @param mediaLocations
     *            the new media locations
     */
    public void setMediaLocations(List<String> mediaLocations) {
        this.mediaLocations = mediaLocations;
    }

    /**
     * Gets the location.
     *
     * @return the location
     */
    public String getLocation() {
        return this.location;
    }

    /**
     * Sets the location.
     *
     * @param location
     *            the new location
     */
    public void setLocation(String location) {
        this.location = location;
    }

}
