package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.wrapper;

import java.util.List;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.ExportFileTypeConfiguration;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.TemplateConfiguration;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.TemplateContent;



/**
 * @author luisvpi
 *
 */
public class ExportConfiguration {

    private ExportFileTypeConfiguration exportFileTypeConfiguration;

    private List<TemplateConfiguration> templatesConfiguration;

    private List<TemplateContent> templatesContent;

    /**
     * @return exportTypeFileConfiguration
     */
    public ExportFileTypeConfiguration getExportFileTypeConfiguration() {
        return exportFileTypeConfiguration;
    }

    /**
     * @return List TemplateConfiguration
     */
    public List<TemplateConfiguration> getTemplatesConfiguration() {
        return templatesConfiguration;
    }

    /**
     * @return List TemplatesContent
     */
    public List<TemplateContent> getTemplatesContent() {
        return templatesContent;
    }

    /**
     * @param exportFileTypeConfiguration
     */
    public void setExportFileTypeConfiguration(ExportFileTypeConfiguration exportFileTypeConfiguration) {
        this.exportFileTypeConfiguration = exportFileTypeConfiguration;
    }

    /**
     * @param templatesConfiguration
     */
    public void setTemplatesConfiguration(List<TemplateConfiguration> templatesConfiguration) {
        this.templatesConfiguration = templatesConfiguration;
    }

    /**
     * @param templatesContent
     */
    public void setTemplatesContent(List<TemplateContent> templatesContent) {
        this.templatesContent = templatesContent;
    }

}
