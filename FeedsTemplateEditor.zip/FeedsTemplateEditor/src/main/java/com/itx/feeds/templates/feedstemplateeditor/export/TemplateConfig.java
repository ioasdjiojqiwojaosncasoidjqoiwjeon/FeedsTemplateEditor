package com.itx.feeds.templates.feedstemplateeditor.export;

import freemarker.template.Template;

/**
 * @author luisvpi
 *
 */
public class TemplateConfig {

    /** Export Header */
    private String header;

    private String footer;

    /** template */
    private Template template;

    /**
     * @return the header
     */
    public String getHeader() {
        return header;
    }

    /**
     * @return the template
     */
    public Template getTemplate() {
        return template;
    }

    /**
     * @param header
     *            the header to set
     */
    public void setHeader(String header) {
        this.header = header;
    }

    /**
     * @param template
     *            the template to set
     */
    public void setTemplate(Template template) {
        this.template = template;
    }

    /**
     * @return the footer
     */
    public String getFooter() {
        return footer;
    }

    /**
     * @param footer
     *            the footer to set
     */
    public void setFooter(String footer) {
        this.footer = footer;
    }

}
