package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class CompositionWrapper.
 */
public class CompositionWrapper {

    /** The part. */
    private String part;

    /** The composition. */
    private List<Composition> composition;

    /**
     * Instantiates a new composition wrapper.
     *
     * @param part
     *            the part
     * @param composition
     *            the composition
     */
    public CompositionWrapper(String part, List<Composition> composition) {
        super();
        this.part = part;
        this.composition = composition;
    }

    /**
     * Instantiates a new composition wrapper.
     */
    public CompositionWrapper() {
        super();
    }

    /**
     * Gets the part.
     *
     * @return the part
     */
    public String getPart() {
        return this.part;
    }

    /**
     * Sets the part.
     *
     * @param part
     *            the new part
     */
    public void setPart(String part) {
        this.part = part;
    }

    /**
     * Gets the composition.
     *
     * @return the composition
     */
    public List<Composition> getComposition() {
        return this.composition;
    }

    /**
     * Sets the composition.
     *
     * @param composition
     *            the new composition
     */
    public void setComposition(List<Composition> composition) {
        this.composition = composition;
    }

}
