package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

// TODO: Auto-generated Javadoc
/**
 * The Class MocaI18nSize.
 */
public class MocaI18nSize {

    /** The sku. */
    private Long sku;

    /** The name. */
    private String name;

    /**
     * Instantiates a new moca i18n size.
     *
     * @param sku
     *            the sku
     * @param name
     *            the name
     */
    public MocaI18nSize(Long sku, String name) {
        super();
        this.sku = sku;
        this.name = name;
    }

    /**
     * Instantiates a new moca i18n size.
     */
    public MocaI18nSize() {
        super();
    }

    /**
     * Gets the sku.
     *
     * @return the sku
     */
    public Long getSku() {
        return this.sku;
    }

    /**
     * Sets the sku.
     *
     * @param sku
     *            the new sku
     */
    public void setSku(Long sku) {
        this.sku = sku;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the name.
     *
     * @param name
     *            the new name
     */
    public void setName(String name) {
        this.name = name;
    }

}
