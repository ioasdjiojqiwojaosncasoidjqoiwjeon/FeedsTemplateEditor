package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

public class PromotionDescription {

    private int languageId;

    private String description;

    /**
     * @param languageId
     * @param description
     */
    public PromotionDescription(int languageId, String description) {
        super();
        this.languageId = languageId;
        this.description = description;
    }

    public PromotionDescription() {
        super();
    }

    /**
     * @return the languageId
     */
    public int getLanguageId() {
        return languageId;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param languageId
     *            the languageId to set
     */
    public void setLanguageId(int languageId) {
        this.languageId = languageId;
    }

    /**
     * @param description
     *            the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

}
