package com.itx.feeds.templates.feedstemplateeditor;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Duration;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.wrapper.ExportConfiguration;

public class RepositoryHttpClient {

	private static final ObjectMapper objectMapper = new ObjectMapper();

	private static final TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
		public java.security.cert.X509Certificate[] getAcceptedIssuers() {
			return null;
		}

		public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
		}

		public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
		}
	} };

	private final HttpClient httpClient;

	private final String host;

	private final String basicAuth;

	public RepositoryHttpClient(String host, String basicAuth) throws KeyManagementException, NoSuchAlgorithmException {
		super();

		this.host = host;
		this.basicAuth = basicAuth;

		final SSLContext sslContext = SSLContext.getInstance("TLS");
		sslContext.init(null, trustAllCerts, new SecureRandom());

		this.httpClient = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1)
				.followRedirects(HttpClient.Redirect.NORMAL).connectTimeout(Duration.ofSeconds(30))
				.sslContext(sslContext).build();
	}

	public ExportConfiguration getExportConfiguration(String exportType, Integer brandId) throws IOException, InterruptedException {

		String uriRequest = new StringBuilder().append(host).append("/exportconfig/brand/").append(brandId)
				.append("/exporttype/").append(exportType).toString();

		HttpRequest request = HttpRequest.newBuilder().GET().uri(URI.create(uriRequest))
				.header("Content-Type", "application/json").header("Authorization", basicAuth).build();

		HttpResponse<String> response = null;
		response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
		return objectMapper.readValue(response.body(), ExportConfiguration.class);
	}
}
