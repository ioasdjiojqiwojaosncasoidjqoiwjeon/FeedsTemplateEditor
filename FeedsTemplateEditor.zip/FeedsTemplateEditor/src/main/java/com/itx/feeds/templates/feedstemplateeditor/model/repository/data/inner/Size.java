package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class Size.
 */
public class Size {

    /** The sku. */
    private Long sku;

    /** The back soon. */
    private String backSoon;

    /** The has stock. */
    private Integer stockQuantity;

    /** The back soon. */
    private String comingSoon;

    /** The stock threshold. */
    private String stockThreshold;

    /** The price. */
    private List<Price> priceList;

    /**
     * Instantiates a new size.
     * 
     * @param sku
     * @param backSoon
     * @param hasStock
     * @param stockThreshold
     * @param priceList
     */
    public Size(Long sku, String backSoon, Integer stockQuantity, String comingSoon, String stockThreshold,
            List<Price> priceList) {
        super();
        this.sku = sku;
        this.backSoon = backSoon;
        this.stockQuantity = stockQuantity;
        this.comingSoon = comingSoon;
        this.stockThreshold = stockThreshold;
        this.priceList = priceList;
    }

    /**
     * Instantiates a new size.
     */
    public Size() {
        super();
    }

    /**
     * Gets the sku.
     *
     * @return the sku
     */
    public Long getSku() {
        return this.sku;
    }

    /**
     * Sets the sku.
     *
     * @param sku
     *            the new sku
     */
    public void setSku(Long sku) {
        this.sku = sku;
    }

    /**
     * Gets the back soon.
     *
     * @return the back soon
     */
    public String getBackSoon() {
        return this.backSoon;
    }

    /**
     * Sets the back soon.
     *
     * @param backSoon
     *            the new back soon
     */
    public void setBackSoon(String backSoon) {
        this.backSoon = backSoon;
    }

    /**
     * Gets the checks for stock.
     *
     * @return the checks for stock
     */
    public Boolean getHasStock() {
        if (stockQuantity != null) {
            return this.stockQuantity >= 1;
        } else {
            return false;
        }
    }

    /**
     * Gets the checks for stock.
     *
     * @return the checks for stock
     */
    public Integer getStockQuantity() {
        return this.stockQuantity;
    }

    /**
     * Sets the checks for stock.
     *
     * @param stockQuantity
     *            the new checks for stock
     */
    public void setStockQuantity(Integer stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    /**
     * @return the comingSoon
     */
    public String getComingSoon() {
        return comingSoon;
    }

    /**
     * @param comingSoon
     *            the comingSoon to set
     */
    public void setComingSoon(String comingSoon) {
        this.comingSoon = comingSoon;
    }

    /**
     * Gets the stock threshold.
     *
     * @return the stock threshold
     */
    public String getStockThreshold() {
        return this.stockThreshold;
    }

    /**
     * Sets the stock threshold.
     *
     * @param stockThreshold
     *            the new stock threshold
     */
    public void setStockThreshold(String stockThreshold) {
        this.stockThreshold = stockThreshold;
    }

    /**
     * Gets the price.
     *
     * @return the price
     */
    public List<Price> getPriceList() {
        return this.priceList;
    }

    /**
     * Sets the price.
     *
     * @param priceList
     */
    public void setPriceList(List<Price> priceList) {
        this.priceList = priceList;
    }

}
