package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

public class Promotion {

    private int promotionId;

    private String name;

    private boolean isExportable;

    private List<PromotionDescription> promotionDescriptions;

    private List<PromotionConfiguration> promotionConfigurations;

    /**
     * @param promotionId
     * @param name
     * @param isExportable
     * @param promotionDescriptions
     * @param promotionConfigurations
     */
    public Promotion(int promotionId, String name, boolean isExportable,
            List<PromotionDescription> promotionDescriptions, List<PromotionConfiguration> promotionConfigurations) {
        super();
        this.promotionId = promotionId;
        this.name = name;
        this.promotionDescriptions = promotionDescriptions;
        this.promotionConfigurations = promotionConfigurations;
        this.isExportable = isExportable;
    }

    /**
     * 
     */
    public Promotion() {
        super();
    }

    /**
     * @return the promotionId
     */
    public int getPromotionId() {
        return promotionId;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the promotionDescriptions
     */
    public List<PromotionDescription> getPromotionDescriptions() {
        return promotionDescriptions;
    }

    /**
     * @return the promotionConfigurations
     */
    public List<PromotionConfiguration> getPromotionConfigurations() {
        return promotionConfigurations;
    }

    /**
     * @param promotionId
     *            the promotionId to set
     */
    public void setPromotionId(int promotionId) {
        this.promotionId = promotionId;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the isExportable
     */
    public boolean getIsExportable() {
        return isExportable;
    }

    /**
     * @param isExportable
     *            the isExportable to set
     */
    public void setIsExportable(boolean isExportable) {
        this.isExportable = isExportable;
    }

    /**
     * @param promotionDescriptions
     *            the promotionDescriptions to set
     */
    public void setPromotionDescriptions(List<PromotionDescription> promotionDescriptions) {
        this.promotionDescriptions = promotionDescriptions;
    }

    /**
     * @param promotionConfigurations
     *            the promotionConfigurations to set
     */
    public void setPromotionConfigurations(List<PromotionConfiguration> promotionConfigurations) {
        this.promotionConfigurations = promotionConfigurations;
    }

}
