package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

// TODO: Auto-generated Javadoc
/**
 * The Class SupportedLanguage.
 */
public class SupportedLanguage {

    /** The id. */
    private int id;

    /** The name. */
    private String name;

    /** The code. */
    private String code;

    /** The country name. */
    private String countryName;

    /** The is rtl. */
    private String isRTL;

    /** The local code. */
    private String localCode;

    /** The local code. */
    private String localeName;

    /**
     * Instantiates a new supported language.
     *
     * @param id
     *            the id
     * @param name
     *            the name
     * @param code
     *            the code
     * @param countryName
     *            the country name
     * @param isRTL
     *            the is rtl
     * @param localCode
     *            the local code
     * @param localeName
     *            the local code
     */
    public SupportedLanguage(int id, String name, String code, String countryName, String isRTL, String localCode,
            String localeName) {
        super();
        this.id = id;
        this.name = name;
        this.code = code;
        this.countryName = countryName;
        this.isRTL = isRTL;
        this.localCode = localCode;
        this.localeName = localeName;
    }

    /**
     * Instantiates a new supported language.
     */
    public SupportedLanguage() {
        super();
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public int getId() {
        return this.id;
    }

    /**
     * Sets the id.
     *
     * @param id
     *            the new id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the name.
     *
     * @param name
     *            the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the code.
     *
     * @return the code
     */
    public String getCode() {
        return this.code;
    }

    /**
     * Sets the code.
     *
     * @param code
     *            the new code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Gets the country name.
     *
     * @return the country name
     */
    public String getCountryName() {
        return this.countryName;
    }

    /**
     * Sets the country name.
     *
     * @param countryName
     *            the new country name
     */
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    /**
     * Gets the checks if is rtl.
     *
     * @return the checks if is rtl
     */
    public String getIsRTL() {
        return this.isRTL;
    }

    /**
     * Sets the checks if is rtl.
     *
     * @param isRTL
     *            the new checks if is rtl
     */
    public void setIsRTL(String isRTL) {
        this.isRTL = isRTL;
    }

    /**
     * Gets the local code.
     *
     * @return the local code
     */
    public String getLocalCode() {
        return this.localCode;
    }

    /**
     * Sets the local code.
     *
     * @param localCode
     *            the new local code
     */
    public void setLocalCode(String localCode) {
        this.localCode = localCode;
    }

    /**
     * Gets the locale name.
     *
     * @return the locale name
     */
    public String getLocaleName() {
        return this.localeName;
    }

    /**
     * Sets the locale name.
     *
     * @param localeName
     *            the new local name
     */
    public void setLocaleName(String localeName) {
        this.localeName = localeName;
    }

}
