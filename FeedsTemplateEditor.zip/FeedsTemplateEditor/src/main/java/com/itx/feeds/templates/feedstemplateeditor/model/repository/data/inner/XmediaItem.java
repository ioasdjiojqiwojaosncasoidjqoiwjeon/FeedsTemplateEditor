package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class XmediaItem.
 */
public class XmediaItem {

    /** The medias. */
    private List<Media> medias;

    /** The set. */
    private Integer set;

    /**
     * Instantiates a new xmedia item.
     *
     * @param medias
     *            the medias
     * @param set
     *            the set
     */
    public XmediaItem(List<Media> medias, Integer set) {
        super();
        this.medias = medias;
        this.set = set;
    }

    /**
     * Instantiates a new xmedia item.
     */
    public XmediaItem() {
        super();
    }

    /**
     * Gets the medias.
     *
     * @return the medias
     */
    public List<Media> getMedias() {
        return this.medias;
    }

    /**
     * Sets the medias.
     *
     * @param medias
     *            the new medias
     */
    public void setMedias(List<Media> medias) {
        this.medias = medias;
    }

    /**
     * Gets the sets the.
     *
     * @return the sets the
     */
    public Integer getSet() {
        return this.set;
    }

    /**
     * Sets the sets the.
     *
     * @param set
     *            the new sets the
     */
    public void setSet(Integer set) {
        this.set = set;
    }

}
