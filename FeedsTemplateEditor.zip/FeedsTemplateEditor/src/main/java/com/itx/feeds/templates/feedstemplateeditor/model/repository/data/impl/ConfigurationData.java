package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl;

// TODO: Auto-generated Javadoc
/**
 * The Class ConfigurationData.
 */
public class ConfigurationData extends AbstractDocumentDataImpl {

    /** The value. */
    private String value;

    /** The description. */
    private String description;

    /**
     * Instantiates a new configuration data.
     *
     * @param value
     *            the value
     * @param description
     *            the description
     */
    public ConfigurationData(String value, String description) {
        super();
        this.value = value;
        this.description = description;
    }

    /**
     * Instantiates a new configuration data.
     */
    public ConfigurationData() {
        super();
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() {
        return this.value;
    }

    /**
     * Sets the value.
     *
     * @param value
     *            the new value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Sets the description.
     *
     * @param description
     *            the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

}
