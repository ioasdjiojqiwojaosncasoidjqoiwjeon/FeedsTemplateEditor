package com.itx.feeds.templates.feedstemplateeditor.model.repository.data;

/**
 * The Interface AbstractDocumentData.
 */
public interface AbstractDocumentData {

}
