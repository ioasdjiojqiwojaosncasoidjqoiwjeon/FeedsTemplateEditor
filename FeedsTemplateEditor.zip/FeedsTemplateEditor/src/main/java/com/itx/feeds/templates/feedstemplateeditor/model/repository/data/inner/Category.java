package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

// TODO: Auto-generated Javadoc
/**
 * The Class Category.
 */
public class Category {

    /** The id category. */
    private Long idCategory;

    /** The name. */
    private String name;

    /** The name en. */
    private String nameEn;

    /** The short description. */
    private String shortDescription;

    /** The description. */
    private String description;

    /** The keywords. */
    private String keywords;

    /** The key. */
    private String key;

    /** The number of products. */
    private Long numberOfProducts;

    /** The type. */
    private int type;

    /** The view category id. */
    private int viewCategoryId;

    /** The subcategories. */
    private List<Category> subcategories;

    /** The category parent */
    @JsonIgnore
    private Category parent;

    /** The attachments. */
    private List<Attachment> attachments;

    /** The sequence. */
    private double sequence;

    /** The old ids. */
    private List<Long> oldIds;

    /** The categoryURL. */
    private String categoryUrl;

    /** The categoryURLParam. */
    private String categoryUrlParam;

    /**
     * Instantiates a new category.
     *
     * @param idCategory
     *            the id category
     * @param name
     *            the name
     * @param nameEn
     *            the name en
     * @param shortDescription
     *            the short description
     * @param description
     *            the description
     * @param keywords
     *            the keywords
     * @param key
     *            the key
     * @param numberOfProducts
     *            the number of products
     * @param type
     *            the type
     * @param viewCategoryId
     *            the view category id
     * @param subcategories
     *            the subcategories
     * @param attachments
     *            the attachments
     * @param sequence
     *            the sequence
     * @param oldIds
     *            the old ids
     */
    public Category(Long idCategory, String name, String nameEn, String shortDescription, String description,
            String keywords, String key, Long numberOfProducts, int type, int viewCategoryId,
            List<Category> subcategories, List<Attachment> attachments, double sequence, List<Long> oldIds,
            String categoryUrl, String categoryUrlParam) {
        super();
        this.idCategory = idCategory;
        this.name = name;
        this.nameEn = nameEn;
        this.shortDescription = shortDescription;
        this.description = description;
        this.keywords = keywords;
        this.key = key;
        this.numberOfProducts = numberOfProducts;
        this.type = type;
        this.viewCategoryId = viewCategoryId;
        this.subcategories = subcategories;
        this.attachments = attachments;
        this.sequence = sequence;
        this.oldIds = oldIds;
        this.categoryUrl = categoryUrl;
        this.categoryUrlParam = categoryUrlParam;
    }

    /**
     * Instantiates a new category.
     */
    public Category() {
        super();
    }

    /**
     * Gets the id category.
     *
     * @return the id category
     */
    public Long getIdCategory() {
        return this.idCategory;
    }

    /**
     * Sets the id category.
     *
     * @param idCategory
     *            the new id category
     */
    public void setIdCategory(Long idCategory) {
        this.idCategory = idCategory;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the name.
     *
     * @param name
     *            the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the name en.
     *
     * @return the name en
     */
    public String getNameEn() {
        return this.nameEn;
    }

    /**
     * Sets the name en.
     *
     * @param nameEn
     *            the new name en
     */
    public void setNameEn(String nameEn) {
        this.nameEn = nameEn;
    }

    /**
     * Gets the short description.
     *
     * @return the short description
     */
    public String getShortDescription() {
        return this.shortDescription;
    }

    /**
     * Sets the short description.
     *
     * @param shortDescription
     *            the new short description
     */
    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Sets the description.
     *
     * @param description
     *            the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Gets the keywords.
     *
     * @return the keywords
     */
    public String getKeywords() {
        return this.keywords;
    }

    /**
     * Sets the keywords.
     *
     * @param keywords
     *            the new keywords
     */
    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    /**
     * Gets the key.
     *
     * @return the key
     */
    public String getKey() {
        return this.key;
    }

    /**
     * Sets the key.
     *
     * @param key
     *            the new key
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * Gets the number of products.
     *
     * @return the number of products
     */
    public Long getNumberOfProducts() {
        return this.numberOfProducts;
    }

    /**
     * Sets the number of products.
     *
     * @param numberOfProducts
     *            the new number of products
     */
    public void setNumberOfProducts(Long numberOfProducts) {
        this.numberOfProducts = numberOfProducts;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public int getType() {
        return this.type;
    }

    /**
     * Sets the type.
     *
     * @param type
     *            the new type
     */
    public void setType(int type) {
        this.type = type;
    }

    /**
     * Gets the view category id.
     *
     * @return the view category id
     */
    public int getViewCategoryId() {
        return this.viewCategoryId;
    }

    /**
     * Sets the view category id.
     *
     * @param viewCategoryId
     *            the new view category id
     */
    public void setViewCategoryId(int viewCategoryId) {
        this.viewCategoryId = viewCategoryId;
    }

    /**
     * Gets the subcategories.
     *
     * @return the subcategories
     */
    public List<Category> getSubcategories() {
        return this.subcategories;
    }

    /**
     * Sets the subcategories.
     *
     * @param subcategories
     *            the new subcategories
     */
    public void setSubcategories(List<Category> subcategories) {
        this.subcategories = subcategories;
    }

    /**
     * Gets the attachments.
     *
     * @return the attachments
     */
    public List<Attachment> getAttachments() {
        return this.attachments;
    }

    /**
     * Sets the attachments.
     *
     * @param attachments
     *            the new attachments
     */
    public void setAttachments(List<Attachment> attachments) {
        this.attachments = attachments;
    }

    /**
     * Gets the sequence.
     *
     * @return the sequence
     */
    public double getSequence() {
        return this.sequence;
    }

    /**
     * Sets the sequence.
     *
     * @param sequence
     *            the new sequence
     */
    public void setSequence(double sequence) {
        this.sequence = sequence;
    }

    /**
     * @return category
     */
    public Category getParent() {
        return parent;
    }

    /**
     * @param parent
     */
    public void setParent(Category parent) {
        this.parent = parent;
    }

    /**
     * Gets the old ids.
     *
     * @return the old ids
     */
    public List<Long> getOldIds() {
        return this.oldIds;
    }

    /**
     * Sets the old ids.
     *
     * @param oldIds
     *            the new old ids
     */
    public void setOldIds(List<Long> oldIds) {
        this.oldIds = oldIds;
    }

    /**
     * @return the categoryURL
     */
    public String getCategoryUrl() {
        return categoryUrl;
    }

    /**
     * @return the categoryURLParam
     */
    public String getCategoryUrlParam() {
        return categoryUrlParam;
    }

    /**
     * @param categoryUrl
     *            the categoryURL to set
     */
    public void setCategoryUrl(String categoryUrl) {
        this.categoryUrl = categoryUrl;
    }

    /**
     * @param categoryUrlParam
     *            the categoryUrlParam to set
     */
    public void setCategoryUrlParam(String categoryUrlParam) {
        this.categoryUrlParam = categoryUrlParam;
    }

}
