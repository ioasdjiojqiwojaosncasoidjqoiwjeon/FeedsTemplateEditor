package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class Xmedia.
 */
public class Xmedia {

    /** The path. */
    private String path;

    /** The xmedia items. */
    private List<XmediaItem> xmediaItems;

    /** The color code. */
    private String colorCode;

    /** The xmedia locations. */
    private List<XmediaLocation> xmediaLocations;

    /**
     * Instantiates a new xmedia.
     *
     * @param path
     *            the path
     * @param xmediaItems
     *            the xmedia items
     * @param colorCode
     *            the color code
     * @param xmediaLocations
     *            the xmedia locations
     */
    public Xmedia(String path, List<XmediaItem> xmediaItems, String colorCode, List<XmediaLocation> xmediaLocations) {
        super();
        this.path = path;
        this.xmediaItems = xmediaItems;
        this.colorCode = colorCode;
        this.xmediaLocations = xmediaLocations;
    }

    /**
     * Instantiates a new xmedia.
     */
    public Xmedia() {
        super();
    }

    /**
     * Gets the path.
     *
     * @return the path
     */
    public String getPath() {
        return this.path;
    }

    /**
     * Sets the path.
     *
     * @param path
     *            the new path
     */
    public void setPath(String path) {
        this.path = path;
    }

    /**
     * Gets the xmedia items.
     *
     * @return the xmedia items
     */
    public List<XmediaItem> getXmediaItems() {
        return this.xmediaItems;
    }

    /**
     * Sets the xmedia items.
     *
     * @param xmediaItems
     *            the new xmedia items
     */
    public void setXmediaItems(List<XmediaItem> xmediaItems) {
        this.xmediaItems = xmediaItems;
    }

    /**
     * Gets the color code.
     *
     * @return the color code
     */
    public String getColorCode() {
        return this.colorCode;
    }

    /**
     * Sets the color code.
     *
     * @param colorCode
     *            the new color code
     */
    public void setColorCode(String colorCode) {
        this.colorCode = colorCode;
    }

    /**
     * Gets the xmedia locations.
     *
     * @return the xmedia locations
     */
    public List<XmediaLocation> getXmediaLocations() {
        return this.xmediaLocations;
    }

    /**
     * Sets the xmedia locations.
     *
     * @param xmediaLocations
     *            the new xmedia locations
     */
    public void setXmediaLocations(List<XmediaLocation> xmediaLocations) {
        this.xmediaLocations = xmediaLocations;
    }

}
