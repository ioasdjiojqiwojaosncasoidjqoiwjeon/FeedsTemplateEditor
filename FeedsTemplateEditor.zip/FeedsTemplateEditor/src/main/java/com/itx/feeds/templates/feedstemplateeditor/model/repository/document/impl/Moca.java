package com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl;

import java.util.List;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl.MocaData;


// TODO: Auto-generated Javadoc
/**
 * The Class Moca.
 */
public class Moca extends AbstractBrandedVersionedDocumentImpl<MocaData> {

    /** The product id. */
    private Integer productId;

    /** The moca store list. */
    private List<MocaStore> mocaStoreList;

    /** The bundle product summaries. */
    private List<Moca> bundleProductSummaries;

    /**
     * Instantiates a new moca.
     *
     * @param data
     *            the data
     * @param feedsVersion
     *            the feeds version
     * @param brandId
     *            the brand id
     * @param productId
     *            the product id
     * @param mocaStoreList
     *            the moca store list
     */
    public Moca(MocaData data, long feedsVersion, Integer brandId, Integer productId, List<MocaStore> mocaStoreList) {
        super(data, feedsVersion, brandId);
        this.productId = productId;
        this.mocaStoreList = mocaStoreList;
    }

    /**
     * Instantiates a new moca.
     */
    public Moca() {
        super();
    }

    /**
     * Gets the product id.
     *
     * @return the product id
     */
    public Integer getProductId() {
        return this.productId;
    }

    /**
     * Sets the product id.
     *
     * @param productId
     *            the new product id
     */
    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    /**
     * Gets the moca store list.
     *
     * @return the moca store list
     */
    public List<MocaStore> getMocaStoreList() {
        return this.mocaStoreList;
    }

    /**
     * Sets the moca store list.
     *
     * @param mocaStoreList
     *            the new moca store list
     */
    public void setMocaStoreList(List<MocaStore> mocaStoreList) {
        this.mocaStoreList = mocaStoreList;
    }

    /**
     * Gets the bundle product summaries.
     *
     * @return the bundle product summaries
     */
    public List<Moca> getBundleProductSummaries() {
        return bundleProductSummaries;
    }

    /**
     * Sets the bundle product summaries.
     *
     * @param bundleProductSummaries
     *            the new bundle product summaries
     */
    public void setBundleProductSummaries(List<Moca> bundleProductSummaries) {
        this.bundleProductSummaries = bundleProductSummaries;
    }

}
