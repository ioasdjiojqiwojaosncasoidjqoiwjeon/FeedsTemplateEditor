package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl;

import java.util.List;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.MocaStoreCategory;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.MocaStoreColor;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Size;

// TODO: Auto-generated Javadoc
/**
 * The Class MocaStoreData.
 */
public class MocaStoreData extends AbstractDocumentDataImpl {

    /** The back soon. */
    private String backSoon;

    /** The categories. */
    private List<MocaStoreCategory> categories;

    /** The sizes. */
    private List<Size> sizes;

    /** The color. */
    private List<MocaStoreColor> colors;

    /**
     * Instantiates a new moca store data.
     *
     * @param backSoon
     *            the back soon
     * @param categories
     *            the categories
     * @param sizes
     *            the sizes
     * @param colors
     *            the color
     */
    public MocaStoreData(String backSoon, List<MocaStoreCategory> categories, List<Size> sizes,
            List<MocaStoreColor> colors) {
        super();
        this.backSoon = backSoon;
        this.categories = categories;
        this.sizes = sizes;
        this.colors = colors;
    }

    /**
     * Instantiates a new moca store data.
     */
    public MocaStoreData() {
        super();
    }

    /**
     * Gets the back soon.
     *
     * @return the back soon
     */
    public String getBackSoon() {
        return this.backSoon;
    }

    /**
     * Sets the back soon.
     *
     * @param backSoon
     *            the new back soon
     */
    public void setBackSoon(String backSoon) {
        this.backSoon = backSoon;
    }

    /**
     * Gets the categories.
     *
     * @return the categories
     */
    public List<MocaStoreCategory> getCategories() {
        return this.categories;
    }

    /**
     * Sets the categories.
     *
     * @param categories
     *            the new categories
     */
    public void setCategories(List<MocaStoreCategory> categories) {
        this.categories = categories;
    }

    /**
     * Gets the sizes.
     *
     * @return the sizes
     */
    public List<Size> getSizes() {
        return this.sizes;
    }

    /**
     * Sets the sizes.
     *
     * @param sizes
     *            the new sizes
     */
    public void setSizes(List<Size> sizes) {
        this.sizes = sizes;
    }

    /**
     * gets the colors
     * 
     * @return Colors list
     */
    public List<MocaStoreColor> getColors() {
        return colors;
    }

    /**
     * Sets the colors.
     * 
     * @param colors
     */
    public void setColors(List<MocaStoreColor> colors) {
        this.colors = colors;
    }

}
