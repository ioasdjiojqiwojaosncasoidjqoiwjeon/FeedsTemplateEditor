package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl;

import java.util.List;

/**
 * @author luisvpi
 *
 */
public class ExportFileTypeConfigurationData extends AbstractDocumentDataImpl {

    /** The typeFile. */
    private String typeFile;

    /** The description. */
    private String description;

    /** The fileGenerationStrategy. */
    private String fileGenerationStrategy;

    /** The fileSplitStrategy. */
    private String fileSplitStrategy;

    /** Send exportPath. */
    private List<String> exportPath;

    /** Send temporaryPath. */
    private String temporaryPath;

    /** Send files or not. */
    private Boolean sendFiles;

    /** Zip files or not. */
    private Boolean zipFiles;

    /** Zip files or not. */
    private String zipExtensionFiles;

    /** Codification */
    private String encoding;

    /** Codification */
    private Boolean encodingWithBOM;

    /** filenamePattern */
    private String filenamePattern;

    /** postUrl. */
    private String postUrl;

    /** postUrlToken. */
    private String postUrlToken;

    /** feedId Colbenson. */
    private String feedId;

    /** The includeBundles. */
    private Boolean includeBundles;

    /** The includeMocacos. */
    private Boolean includeMocacos;

    /** The includeGrucacos. */
    private Boolean includeGrucacos;

    /** The includeGrucacos. */
    private Boolean includeStylisms;

    /** The discardProductsWithoutImage. */
    private Boolean discardProductsWithoutImage;

    /** The includeGrucacos. */
    private Boolean loadCategoriesTree;

    /**
     * Expoort TypeFile Config
     */
    public ExportFileTypeConfigurationData() {
        super();
    }

    /**
     * @param typeFile
     * @param description
     * @param fileGenerationStrategy
     * @param fileSplitStrategy
     * @param exportPath
     * @param temporaryPath
     * @param sendFiles
     * @param zipFiles
     * @param zipExtensionFiles
     * @param encoding
     * @param encodingWithBOM
     * @param filenamePattern
     * @param postUrl
     * @param postUrlToken
     * @param feedId
     * @param includeBundles
     * @param includeMocacos
     * @param includeGrucacos
     * @param discardProductsWithoutImage
     * @param loadCategoriesTree
     */
    public ExportFileTypeConfigurationData(String typeFile, String description, String fileGenerationStrategy,
            String fileSplitStrategy, List<String> exportPath, String temporaryPath, Boolean sendFiles,
            Boolean zipFiles, String zipExtensionFiles, String encoding, Boolean encodingWithBOM,
            String filenamePattern, String postUrl, String postUrlToken, String feedId, Boolean includeBundles,
            Boolean includeMocacos, Boolean includeGrucacos, Boolean includeStylisms,
            Boolean discardProductsWithoutImage, Boolean loadCategoriesTree) {
        super();
        this.typeFile = typeFile;
        this.description = description;
        this.fileGenerationStrategy = fileGenerationStrategy;
        this.fileSplitStrategy = fileSplitStrategy;
        this.exportPath = exportPath;
        this.temporaryPath = temporaryPath;
        this.sendFiles = sendFiles;
        this.zipFiles = zipFiles;
        this.zipExtensionFiles = zipExtensionFiles;
        this.encoding = encoding;
        this.encodingWithBOM = encodingWithBOM;
        this.filenamePattern = filenamePattern;
        this.postUrl = postUrl;
        this.postUrlToken = postUrlToken;
        this.feedId = feedId;
        this.includeBundles = includeBundles;
        this.includeMocacos = includeMocacos;
        this.includeGrucacos = includeGrucacos;
        this.includeStylisms = includeStylisms;
        this.discardProductsWithoutImage = discardProductsWithoutImage;
        this.loadCategoriesTree = loadCategoriesTree;

    }

    /**
     * Gets the getTypeFile.
     *
     * @return the getTypeFile
     */
    public String getTypeFile() {
        return typeFile;
    }

    /**
     * Gets the getDescription.
     *
     * @return the getDescription
     */
    public String getDescription() {
        return description;
    }

    /**
     * Gets the fileGenerationStrategy.
     *
     * @return the fileGenerationStrategy
     */
    public String getFileGenerationStrategy() {
        return fileGenerationStrategy;
    }

    /**
     * Gets the sendFiles.
     *
     * @return the sendFiles
     */
    public Boolean getSendFiles() {
        return sendFiles;
    }

    /**
     * Gets the getIncludeBundles.
     *
     * @return the getIncludeBundles
     */
    public Boolean getIncludeBundles() {
        return includeBundles;
    }

    /**
     * Sets the typeFile.
     *
     * @param typeFile
     *            the new typeFile
     */
    public void setTypeFile(String typeFile) {
        this.typeFile = typeFile;
    }

    /**
     * Sets the description.
     *
     * @param description
     *            the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Sets the fileGenerationStrategy.
     *
     * @param fileGenerationStrategy
     *            the new generateOneFile
     */
    public void setFileGenerationStrategy(String fileGenerationStrategy) {
        this.fileGenerationStrategy = fileGenerationStrategy;
    }

    /**
     * Sets the sendFiles.
     *
     * @param sendFiles
     *            the new sendFiles
     */
    public void setSendFiles(Boolean sendFiles) {
        this.sendFiles = sendFiles;
    }

    /**
     * @return the zipFiles
     */
    public Boolean getZipFiles() {
        return zipFiles;
    }

    /**
     * @return the encoding
     */
    public String getEncoding() {
        return encoding;
    }

    /**
     * @param zipFiles
     *            the zipFiles to set
     */
    public void setZipFiles(Boolean zipFiles) {
        this.zipFiles = zipFiles;
    }

    /**
     * @return the zipExtensionFiles
     */
    public String getZipExtensionFiles() {
        return zipExtensionFiles;
    }

    /**
     * @param zipExtensionFiles
     *            the zipExtensionFiles to set
     */
    public void setZipExtensionFiles(String zipExtensionFiles) {
        this.zipExtensionFiles = zipExtensionFiles;
    }

    /**
     * @param encoding
     *            the encoding to set
     */
    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    /**
     * @return the encodingWithBOM
     */
    public Boolean getEncodingWithBOM() {
        return encodingWithBOM;
    }

    /**
     * @param encodingWithBOM
     *            the encodingWithBOM to set
     */
    public void setEncodingWithBOM(Boolean encodingWithBOM) {
        this.encodingWithBOM = encodingWithBOM;
    }

    /**
     * @return the filenamePattern
     */
    public String getFilenamePattern() {
        return filenamePattern;
    }

    /**
     * @param filenamePattern
     *            the filenamePattern to set
     */
    public void setFilenamePattern(String filenamePattern) {
        this.filenamePattern = filenamePattern;
    }

    /**
     * Sets the includeBundles.
     *
     * @param includeBundles
     *            the new includeBundles
     */
    public void setIncludeBundles(Boolean includeBundles) {
        this.includeBundles = includeBundles;
    }

    /**
     * @return the fileSplitStrategy
     */
    public String getFileSplitStrategy() {
        return fileSplitStrategy;
    }

    /**
     * @return the exportPath
     */
    public List<String> getExportPath() {
        return exportPath;
    }

    /**
     * @return the temporaryPath
     */
    public String getTemporaryPath() {
        return temporaryPath;
    }

    /**
     * @param temporaryPath
     *            the temporaryPath to set
     */
    public void setTemporaryPath(String temporaryPath) {
        this.temporaryPath = temporaryPath;
    }

    /**
     * @return the postUrl
     */
    public String getPostUrl() {
        return postUrl;
    }

    /**
     * @return the postUrlToken
     */
    public String getPostUrlToken() {
        return postUrlToken;
    }

    /**
     * @return the includeMocacos
     */
    public Boolean getIncludeMocacos() {
        return includeMocacos;
    }

    /**
     * @return the includeGrucacos
     */
    public Boolean getIncludeGrucacos() {
        return includeGrucacos;
    }

    /**
     * @return the includeStylisms
     */
    public Boolean getIncludeStylisms() {
        return includeStylisms;
    }

    /**
     * @param fileSplitStrategy
     *            the fileSplitStrategy to set
     */
    public void setFileSplitStrategy(String fileSplitStrategy) {
        this.fileSplitStrategy = fileSplitStrategy;
    }

    /**
     * @param exportPath
     *            the exportPath to set
     */
    public void setExportPath(List<String> exportPath) {
        this.exportPath = exportPath;
    }

    /**
     * @param postUrl
     *            the postUrl to set
     */
    public void setPostUrl(String postUrl) {
        this.postUrl = postUrl;
    }

    /**
     * @param postUrlToken
     *            the postUrlToken to set
     */
    public void setPostUrlToken(String postUrlToken) {
        this.postUrlToken = postUrlToken;
    }

    /**
     * @param includeMocacos
     *            the includeMocacos to set
     */
    public void setIncludeMocacos(Boolean includeMocacos) {
        this.includeMocacos = includeMocacos;
    }

    /**
     * @param includeGrucacos
     *            the includeGrucacos to set
     */
    public void setIncludeGrucacos(Boolean includeGrucacos) {
        this.includeGrucacos = includeGrucacos;
    }

    /**
     * @param includeStylisms
     *            the includeStylisms to set
     */
    public void setIncludeStylisms(Boolean includeStylisms) {
        this.includeStylisms = includeStylisms;
    }

    /**
     * @return the feedId
     */
    public String getFeedId() {
        return feedId;
    }

    /**
     * @param feedId
     *            the feedId to set
     */
    public void setFeedId(String feedId) {
        this.feedId = feedId;
    }

    /**
     * @return the discardProductsWithoutImage
     */
    public Boolean getDiscardProductsWithoutImage() {
        return discardProductsWithoutImage;
    }

    /**
     * @param discardProductsWithoutImage
     *            the discardProductsWithoutImage to set
     */
    public void setDiscardProductsWithoutImage(Boolean discardProductsWithoutImage) {
        this.discardProductsWithoutImage = discardProductsWithoutImage;
    }

    /**
     * @return the loadCategoriesTree
     */
    public Boolean getLoadCategoriesTree() {
        return loadCategoriesTree;
    }

    /**
     * @param loadCategoriesTree
     *            the loadCategoriesTree to set
     */
    public void setLoadCategoriesTree(Boolean loadCategoriesTree) {
        this.loadCategoriesTree = loadCategoriesTree;
    }

}