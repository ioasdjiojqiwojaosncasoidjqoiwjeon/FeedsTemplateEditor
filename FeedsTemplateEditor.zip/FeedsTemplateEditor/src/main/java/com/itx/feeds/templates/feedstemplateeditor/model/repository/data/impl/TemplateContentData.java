package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl;

/**
 * @author luisvpi
 *
 */
public class TemplateContentData extends AbstractDocumentDataImpl {

    /** The feed. */
    private String content;

    /**
     * Instantiates a new feeds Template Content data.
     *
     * @param content
     *            the content
     */
    public TemplateContentData(String content) {
        super();
        this.content = content;
    }

    /**
     * Instantiates a new Template data.
     */
    public TemplateContentData() {
        super();
    }

    /**
     * Gets the content.
     *
     * @return the content
     */
    public String getContent() {
        return this.content;
    }

    /**
     * Sets the content.
     *
     * @param content
     *            the new content
     */
    public void setContent(String content) {
        this.content = content;
    }

}
