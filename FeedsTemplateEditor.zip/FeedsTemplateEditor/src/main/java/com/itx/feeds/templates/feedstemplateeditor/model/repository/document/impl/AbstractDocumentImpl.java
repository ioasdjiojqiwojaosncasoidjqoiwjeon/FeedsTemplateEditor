package com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.AbstractDocumentData;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.AbstractDocument;

// TODO: Auto-generated Javadoc
/**
 * The Class AbstractDocumentImpl.
 *
 * @author LUISVPI
 * @param <E>
 *            the element type
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class AbstractDocumentImpl<E extends AbstractDocumentData> implements AbstractDocument<E> {

    /** The data. */
    protected E data;

    /**
     * Instantiates a new abstract document impl.
     */
    public AbstractDocumentImpl() {
        super();
    }

    /**
     * Instantiates a new abstract document impl.
     *
     * @param data
     *            the data
     */
    public AbstractDocumentImpl(E data) {
        super();
        this.data = data;
    }

    /**
     * get Data.
     * 
     * @return Data.
     */
    @Override
    public E getData() {
        return this.data;
    }

    /**
     * Set Data.
     *
     * @param data
     */
    @Override
    public void setData(E data) {
        this.data = data;
    }
}
