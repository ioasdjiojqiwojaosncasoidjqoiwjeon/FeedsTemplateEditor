package com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl.BrandData;

// TODO: Auto-generated Javadoc
/**
 * The Class Brand.
 */
public class Brand extends AbstractDocumentImpl<BrandData> {

    /** The brand id. */
    private Integer brandId;

    /**
     * Instantiates a new brand.
     *
     * @param data
     *            the data
     * @param brandId
     *            the brand id
     */
    public Brand(BrandData data, Integer brandId) {
        super(data);
        this.brandId = brandId;
    }

    /**
     * Instantiates a new brand.
     */
    public Brand() {
        super();
    }

    /**
     * Gets the brand id.
     *
     * @return the brand id
     */
    public Integer getBrandId() {
        return this.brandId;
    }

    /**
     * Sets the brand id.
     *
     * @param brandId
     *            the new brand id
     */
    public void setBrandId(Integer brandId) {
        this.brandId = brandId;
    }

}
