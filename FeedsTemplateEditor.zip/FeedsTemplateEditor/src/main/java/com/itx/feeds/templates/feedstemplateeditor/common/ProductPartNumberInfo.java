package com.itx.feeds.templates.feedstemplateeditor.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

// TODO: Auto-generated Javadoc
/**
 * The Class ProductPartNumberInfo.
 *
 * @author LUISVPI
 */
public class ProductPartNumberInfo extends PartNumberInfo {

    /** The empty partnumber. */
    public static String EMPTY_PARTNUMBER = "00000000-V2000";

    /** The pattern. */
    public static Pattern pattern = Pattern.compile("(\\d)(\\d{4})(\\d{3})-([VI])(\\d{4})");

    /** The section. */
    protected final Integer section;

    /**
     * Instantiates a new product part number info.
     *
     * @param section
     *            the section
     * @param model
     *            the model
     * @param quality
     *            the quality
     * @param season
     *            the season
     * @param year
     *            the year
     */
    protected ProductPartNumberInfo(Integer section, Integer model, Integer quality, String season, Integer year) {
        super(model, quality, season, year);
        this.section = section;
    }

    /**
     * Gets the pattern.
     *
     * @return the pattern
     */
    public static Pattern getPattern() {
        return pattern;
    }

    /**
     * Gets the section.
     *
     * @return the section
     */
    public Integer getSection() {
        return section;
    }

    /**
     * Builds the.
     *
     * @param partNumber
     *            the part number
     * @return the product part number info
     */
    public static ProductPartNumberInfo build(String partNumber) {
        Matcher m = pattern.matcher(partNumber);
        if (!m.matches()) {
            return null;
        }
        return new ProductPartNumberInfo(Integer.valueOf(m.group(1)), Integer.valueOf(m.group(2)),
                Integer.valueOf(m.group(3)), m.group(4), Integer.valueOf(m.group(5)));
    }

    /**
     * @return string
     */
    @Override
    public String toProductPartNumber() {
        return String.format("%01d%04d%03d-%s%04d", section, model, quality, season, year);
    }

    /**
     * To product part number without season.
     *
     * @return the string
     */
    public String toProductPartNumberWithoutSeason() {
        return String.format("%01d%04d%03d", section, model, quality);
    }

    /**
     * @param color
     * @return string
     */
    @Override
    public String appendColorPartNumber(Integer color) {
        return String.format("%01d%04d%03d%03d-%s%04d", section, model, quality, color, season, year);
    }

}