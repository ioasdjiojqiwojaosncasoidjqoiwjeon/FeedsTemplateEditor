package com.itx.feeds.templates.feedstemplateeditor;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.fxmisc.richtext.CodeArea;
import org.fxmisc.richtext.LineNumberFactory;
import org.fxmisc.richtext.StyleClassedTextArea;

import com.itx.feeds.templates.feedstemplateeditor.model.ExportableModel;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.wrapper.ExportConfiguration;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.TemplateContent;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.stage.FileChooser;
import javafx.stage.Window;

public class FeedsTemplateEditorController {

	private static final String ROOT_DUMMY_ITEM = "Loaded Model Files";

	private ExportConfiguration exportConfiguration;

	private Map<String, TemplateContent> loadedTemplateContentMap;

	private Map<String, TemplateContent> editedTemplateContentMap;

	private Map<String, String> loadedModelContentMap;

	private Map<String, String> editedModelContentMap;

	private ModelLoader modelLoader = new ModelLoader();

	private TemplateModelParser modelParser = new TemplateModelParser();

	private ExportableModel exportableModel;

	@FXML
	private TextField exportTypeText;

	@FXML
	private TextField brandIdText;

	@FXML
	private CodeArea templateContentText;

	@FXML
	private StyleClassedTextArea modelContentText;

	@FXML
	private StyleClassedTextArea templateResultText;

	@FXML
	private TreeView<String> templatesTreeView;

	@FXML
	private TreeView<String> modelsTreeView;

	public void initialize() {
		templateContentText.setParagraphGraphicFactory(LineNumberFactory.get(templateContentText));
		templateContentText.setWrapText(true);
		templateContentText.setStyle("-fx-font-family: consolas; -fx-font-size: 10pt;");
		modelContentText.setStyle("-fx-font-family: consolas; -fx-font-size: 10pt;");

		templateContentText.focusedProperty().addListener((obs, oldFocus, newFocus) -> {
			if (templatesTreeView.getSelectionModel().getSelectedItem() != null && oldFocus && !newFocus) {
				TemplateContent templateContent = editedTemplateContentMap
						.get(templatesTreeView.getSelectionModel().getSelectedItem().getValue());
				if (templateContent != null) {
					templateContent.getData().setContent(templateContentText.getText());
				}
			}
		});

		modelsTreeView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelect, newSelect) -> {
			if (oldSelect != newSelect && !ROOT_DUMMY_ITEM.equals(newSelect.getValue())) {
				if (oldSelect != null && oldSelect.getValue() != ROOT_DUMMY_ITEM) {
					String modelContentSave = editedModelContentMap.get(oldSelect.getValue());
					if (modelContentSave != null) {
						modelContentSave = modelContentText.getText();
					}
				}

				if (!newSelect.getValue().equals(ROOT_DUMMY_ITEM)) {
					String modelContentRead = editedModelContentMap.get(newSelect.getValue());
					if (modelContentRead != null) {
						modelContentText.replaceText(modelContentRead);
					}

				}
			}
		});

		templatesTreeView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelect, newSelect) -> {
			if (oldSelect != newSelect && exportConfiguration != null) {
				if (oldSelect != null) {
					TemplateContent templateContentSave = editedTemplateContentMap.get(oldSelect.getValue());
					if (templateContentSave != null) {
						templateContentSave.getData().setContent(templateContentText.getText());
					}
				}

				TemplateContent templateContentRead = editedTemplateContentMap.get(newSelect.getValue());
				if (templateContentRead != null) {
					templateContentText.replaceText(templateContentRead.getData().getContent());
				}
			}
		});
	}

	@FXML
	protected void onLoadExportTypeBtnClick() {
		try {
			final RepositoryHttpClient repositoryHttpClient = new RepositoryHttpClient(
					FeedEnvironmentEnum.PRE.getHost(), FeedEnvironmentEnum.PRE.getBasicAuth());

			this.exportConfiguration = repositoryHttpClient.getExportConfiguration(exportTypeText.getText(),
					Integer.parseInt(brandIdText.getText()));

			templateContentText.append(exportConfiguration.getTemplatesContent().get(0).getData().getContent(), "");

			loadedTemplateContentMap = exportConfiguration.getTemplatesContent().stream()
					.collect(Collectors.toMap(TemplateContent::getTemplateName, Function.identity()));

			editedTemplateContentMap = new HashMap<>(loadedTemplateContentMap);

			TreeItem<String> rootItem = new TreeItem<String>(
					exportConfiguration.getTemplatesConfiguration().get(0).getData().getMainTemplate());

			rootItem.setExpanded(true);
			for (String template : exportConfiguration.getTemplatesConfiguration().get(0).getData()
					.getTemplateNamesList()) {
				TreeItem<String> item = new TreeItem<String>(template);
				rootItem.getChildren().add(item);
			}
			templatesTreeView.setRoot(rootItem);

			templatesTreeView.getSelectionModel().select(0);

		} catch (NumberFormatException | IOException | InterruptedException | KeyManagementException
				| NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
	}

	@FXML
	protected void onLoadModelBtnClick() {

		FileChooser fileChooser = new FileChooser();
		FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("JSON files (*.json)", "*.json");
		fileChooser.setTitle("Seleccione fichero: Moca, Store, Brand, CategoriesList, Configuration");
		fileChooser.getExtensionFilters().add(extFilter);
		List<File> filesToLoad = fileChooser.showOpenMultipleDialog(Window.getWindows().get(0));
		if (filesToLoad != null && !filesToLoad.isEmpty()) {
			this.exportableModel = modelLoader.getExportableModelFromFiles(filesToLoad);

			TreeItem<String> rootItem = new TreeItem<String>("Loaded Model Files");
			rootItem.setExpanded(true);
			for (File fileModel : filesToLoad) {
				TreeItem<String> childItem = new TreeItem<String>(fileModel.getAbsolutePath());
				rootItem.getChildren().add(childItem);
			}

			loadedModelContentMap = filesToLoad.stream().collect(Collectors.toMap(File::getAbsolutePath, file -> {
				try {
					return Files.readString(Path.of(file.getAbsolutePath()));
				} catch (IOException e) {
					e.printStackTrace();
				}
				return StringUtils.EMPTY;
			}));
			editedModelContentMap = new HashMap<>(loadedModelContentMap);

			modelsTreeView.setRoot(rootItem);
			modelsTreeView.getSelectionModel().select(1);
		}

	}

	@FXML
	protected void onParseBtnClick() {

		templateResultText.replaceText(modelParser.parseExportableModelWithTemplateByStrategy(exportableModel,
				exportConfiguration, editedTemplateContentMap));
	}
}
