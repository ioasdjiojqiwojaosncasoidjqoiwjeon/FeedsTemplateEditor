package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

// TODO: Auto-generated Javadoc
/**
 * The Class ExtraInfo.
 */
public class ExtraInfo {

    /** The plano. */
    private String plano;

    /** The modelo. */
    private String modelo;

    /** The set. */
    private String set;

    /**
     * Instantiates a new extra info.
     *
     * @param plano
     *            the plano
     */
    public ExtraInfo(String plano) {
        super();
        this.plano = plano;
    }

    /**
     * Instantiates a new extra info.
     */
    public ExtraInfo() {
        super();
    }

    /**
     * Gets the plano.
     *
     * @return the plano
     */
    public String getPlano() {
        return this.plano;
    }

    /**
     * Sets the plano.
     *
     * @param plano
     *            the new plano
     */
    public void setPlano(String plano) {
        this.plano = plano;
    }

    /**
     * Gets the modelo.
     *
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * Gets the sets the.
     *
     * @return the sets the
     */
    public String getSet() {
        return set;
    }

    /**
     * Sets the modelo.
     *
     * @param modelo
     *            the new modelo
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * Sets the sets the.
     *
     * @param set
     *            the new sets the
     */
    public void setSet(String set) {
        this.set = set;
    }

}
