package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl;

import java.util.List;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.StoreCatalogLanguageCategories;


// TODO: Auto-generated Javadoc
/**
 * The Class CategoriesListData.
 */
public class CategoriesListData extends AbstractDocumentDataImpl {

    /** The categories. */
    private List<StoreCatalogLanguageCategories> storeCatalogLanguageCategories;

    /**
     * Instantiates a new categories list data.
     *
     * @param storeCatalogLanguageCategories
     *            the storeCatalogLanguageCategories
     */
    public CategoriesListData(List<StoreCatalogLanguageCategories> storeCatalogLanguageCategories) {
        super();
        this.storeCatalogLanguageCategories = storeCatalogLanguageCategories;
    }

    /**
     * Instantiates a new categories list data.
     */
    public CategoriesListData() {
        super();
    }

    /**
     * Gets the categories.
     *
     * @return the categories
     */
    public List<StoreCatalogLanguageCategories> getStoreCatalogLanguageCategories() {
        return this.storeCatalogLanguageCategories;
    }

    /**
     * Sets the categories.
     *
     * @param storeCatalogLanguageCategories
     *            the new categories
     */
    public void setStoreCategories(List<StoreCatalogLanguageCategories> storeCatalogLanguageCategories) {
        this.storeCatalogLanguageCategories = storeCatalogLanguageCategories;
    }

}
