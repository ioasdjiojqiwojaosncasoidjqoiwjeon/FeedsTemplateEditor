package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

// TODO: Auto-generated Javadoc
/**
 * The Class MocaI18nCategory.
 */
public class MocaI18nCategory {

    /** The id. */
    private Long id;

    /** The identifier. */
    private String identifier;

    /** The name. */
    private String name;

    /** The name. */
    private Long relatedCatentryId;

    /**
     * Instantiates a new moca i18n category.
     *
     * @param id
     *            the id
     * @param identifier
     *            the identifier
     * @param name
     *            the name
     */
    public MocaI18nCategory(Long id, String identifier, String name, Long relatedCatentryId) {
        super();
        this.id = id;
        this.identifier = identifier;
        this.name = name;
        this.relatedCatentryId = relatedCatentryId;
    }

    /**
     * Instantiates a new moca i18n category.
     */
    public MocaI18nCategory() {
        super();
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
        return this.id;
    }

    /**
     * Sets the id.
     *
     * @param id
     *            the new id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Gets the identifier.
     *
     * @return the identifier
     */
    public String getIdentifier() {
        return this.identifier;
    }

    /**
     * Sets the identifier.
     *
     * @param identifier
     *            the new identifier
     */
    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the name.
     *
     * @param name
     *            the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the relatedCatentryId
     */
    public Long getRelatedCatentryId() {
        return relatedCatentryId;
    }

    /**
     * @param relatedCatentryId
     *            the relatedCatentryId to set
     */
    public void setRelatedCatentryId(Long relatedCatentryId) {
        this.relatedCatentryId = relatedCatentryId;
    }

}
