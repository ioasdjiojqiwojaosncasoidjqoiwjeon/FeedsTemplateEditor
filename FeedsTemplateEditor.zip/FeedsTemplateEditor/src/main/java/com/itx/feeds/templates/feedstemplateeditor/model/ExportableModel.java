package com.itx.feeds.templates.feedstemplateeditor.model;

import java.util.List;
import java.util.Map;
import java.util.SortedMap;

import org.javatuples.Quartet;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Category;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.SupportedLanguage;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.Brand;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.Moca;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.MocaI18n;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.MocaStore;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.Store;

public class ExportableModel {

	private Brand brand; 
	
	private Moca moca;
	
	private MocaStore mocaStore;
	
	private MocaI18n mocaI18n;
	
	private List<MocaI18n> mocaI18ns;
	
	private List<MocaStore> mocaStores;
	
	private Map<Integer, Store> storesMap;
	
	private Store store;
	
	private SupportedLanguage language;
	
	private SortedMap<Quartet<Integer, Integer, Integer, Long>, Category> categoriesMap;
	
	private Map<Quartet<String, Integer, Integer, Integer>, String> configurationMap;

	public ExportableModel(Brand brand, Moca moca, MocaStore mocaStore, MocaI18n mocaI18n, List<MocaI18n> mocaI18ns,
			List<MocaStore> mocaStores, Map<Integer, Store> storesMap, Store store, SupportedLanguage language,
			SortedMap<Quartet<Integer, Integer, Integer, Long>, Category> categoriesMap,
			Map<Quartet<String, Integer, Integer, Integer>, String> configurationMap) {
		super();
		this.brand = brand;
		this.moca = moca;
		this.mocaStore = mocaStore;
		this.mocaI18n = mocaI18n;
		this.mocaI18ns = mocaI18ns;
		this.mocaStores = mocaStores;
		this.storesMap = storesMap;
		this.store = store;
		this.language = language;
		this.categoriesMap = categoriesMap;
		this.configurationMap = configurationMap;
	}

	public Brand getBrand() {
		return brand;
	}

	public Moca getMoca() {
		return moca;
	}

	public MocaStore getMocaStore() {
		return mocaStore;
	}

	public MocaI18n getMocaI18n() {
		return mocaI18n;
	}

	public List<MocaI18n> getMocaI18ns() {
		return mocaI18ns;
	}

	public List<MocaStore> getMocaStores() {
		return mocaStores;
	}

	public Map<Integer, Store> getStoresMap() {
		return storesMap;
	}

	public Store getStore() {
		return store;
	}

	public SupportedLanguage getLanguage() {
		return language;
	}

	public SortedMap<Quartet<Integer, Integer, Integer, Long>, Category> getCategoriesMap() {
		return categoriesMap;
	}

	public Map<Quartet<String, Integer, Integer, Integer>, String> getConfigurationMap() {
		return configurationMap;
	}
	
}
