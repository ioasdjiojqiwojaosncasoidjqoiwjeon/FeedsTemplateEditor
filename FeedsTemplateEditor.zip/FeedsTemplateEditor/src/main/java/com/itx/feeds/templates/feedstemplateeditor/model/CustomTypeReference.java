package com.itx.feeds.templates.feedstemplateeditor.model;

import org.springframework.core.ParameterizedTypeReference;
import java.lang.reflect.Type;
import com.fasterxml.jackson.core.type.TypeReference;

public class CustomTypeReference extends TypeReference<Object>{
    private final Type type;

    public CustomTypeReference(ParameterizedTypeReference pt){
        this.type = pt.getType();
    }

    @Override
    public Type getType() {
        return type;
    }
}
