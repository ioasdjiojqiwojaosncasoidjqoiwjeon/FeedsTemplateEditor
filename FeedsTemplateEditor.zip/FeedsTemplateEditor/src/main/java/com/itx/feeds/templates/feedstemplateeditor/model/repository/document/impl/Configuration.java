package com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl.ConfigurationData;

// TODO: Auto-generated Javadoc
/**
 * The Class Configuration.
 */
public class Configuration extends AbstractDocumentImpl<ConfigurationData> {

    /** The key. */
    private String key;

    /** The brand id. */
    private Integer brandId;

    /** The store id. */
    private Integer storeId;

    /** The language id. */
    private Integer languageId;

    /**
     * Instantiates a new configuration.
     *
     * @param data
     *            the data
     * @param key
     *            the key
     * @param brandId
     *            the brand id
     * @param storeId
     *            the store id
     * @param languageId
     *            the language id
     */
    public Configuration(ConfigurationData data, String key, Integer brandId, Integer storeId, Integer languageId) {
        super(data);
        this.key = key;
        this.brandId = brandId;
        this.storeId = storeId;
        this.languageId = languageId;
    }

    /**
     * Instantiates a new configuration.
     */
    public Configuration() {
        super();
    }

    /**
     * Gets the key.
     *
     * @return the key
     */
    public String getKey() {
        return this.key;
    }

    /**
     * Sets the key.
     *
     * @param key
     *            the new key
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * Gets the brand id.
     *
     * @return the brand id
     */
    public Integer getBrandId() {
        return this.brandId;
    }

    /**
     * Sets the brand id.
     *
     * @param brandId
     *            the new brand id
     */
    public void setBrandId(Integer brandId) {
        this.brandId = brandId;
    }

    /**
     * Gets the store id.
     *
     * @return the store id
     */
    public Integer getStoreId() {
        return this.storeId;
    }

    /**
     * Sets the store id.
     *
     * @param storeId
     *            the new store id
     */
    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    /**
     * Gets the language id.
     *
     * @return the language id
     */
    public Integer getLanguageId() {
        return this.languageId;
    }

    /**
     * Sets the language id.
     *
     * @param languageId
     *            the new language id
     */
    public void setLanguageId(Integer languageId) {
        this.languageId = languageId;
    }

}
