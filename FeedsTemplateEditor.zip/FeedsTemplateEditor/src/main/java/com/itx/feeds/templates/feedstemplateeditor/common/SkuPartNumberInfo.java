package com.itx.feeds.templates.feedstemplateeditor.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

// TODO: Auto-generated Javadoc
/**
 * The Class SkuPartNumberInfo.
 *
 * @author LUISVPI
 */
public class SkuPartNumberInfo extends ColorPartNumberInfo {

    /** The pattern. */
    public static Pattern pattern = Pattern.compile("(\\d)(\\d{4})(\\d{3})(\\d{3})(\\d{2})-([VI])(\\d{4})");

    /** The size. */
    protected final Integer size;

    /**
     * Instantiates a new sku part number info.
     *
     * @param product
     *            the product
     * @param model
     *            the model
     * @param quality
     *            the quality
     * @param color
     *            the color
     * @param size
     *            the size
     * @param season
     *            the season
     * @param year
     *            the year
     */
    protected SkuPartNumberInfo(Integer product, Integer model, Integer quality, Integer color, Integer size,
            String season, Integer year) {
        super(product, model, quality, color, season, year);
        this.size = size;
    }

    /**
     * @return string
     */
    @Override
    public String toColorPartNumber() {
        return String.format("%01d%04d%03d%03d-%s%04d", section, model, quality, color, season, year);
    }

    /**
     * Gets the size.
     *
     * @return the size
     */
    public Integer getSize() {
        return size;
    }

    /**
     * Builds the.
     *
     * @param partNumber
     *            the part number
     * @return the sku part number info
     */
    public static SkuPartNumberInfo build(String partNumber) {
        Matcher m = pattern.matcher(partNumber);
        if (!m.matches()) {
            return null;
        }
        return new SkuPartNumberInfo(Integer.valueOf(m.group(1)), Integer.valueOf(m.group(2)),
                Integer.valueOf(m.group(3)), Integer.valueOf(m.group(4)), Integer.valueOf(m.group(5)), m.group(6),
                Integer.valueOf(m.group(7)));
    }
}