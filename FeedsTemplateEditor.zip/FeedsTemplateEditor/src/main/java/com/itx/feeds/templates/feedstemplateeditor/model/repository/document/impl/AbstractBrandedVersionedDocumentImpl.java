package com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.AbstractDocumentData;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.AbstractBrandedVersionedDocument;

// TODO: Auto-generated Javadoc
/**
 * The Class AbstractBrandedVersionedDocumentImpl.
 *
 * @param <E>
 *            the element type
 */
public abstract class AbstractBrandedVersionedDocumentImpl<E extends AbstractDocumentData>
        extends AbstractBrandedDocumentImpl<E> implements AbstractBrandedVersionedDocument<E> {

    /** The feeds version. */
    protected long feedsVersion;

    /**
     * Instantiates a new abstract branded versioned document impl.
     *
     * @param data
     *            the data
     * @param feedsVersion
     *            the feeds version
     * @param brandId
     *            the brand id
     */
    public AbstractBrandedVersionedDocumentImpl(E data, long feedsVersion, Integer brandId) {
        super(data, brandId);
        this.feedsVersion = feedsVersion;

    }

    /**
     * Instantiates a new abstract branded versioned document impl.
     */
    public AbstractBrandedVersionedDocumentImpl() {
        super();
    }

    /**
     * get the versionId.
     *
     * @return the long
     */
    @Override
    public long getFeedsVersion() {
        return this.feedsVersion;
    }

    /**
     * set the versionId.
     *
     * @param feedsVersion
     * @return the string
     */
    @Override
    public void setFeedsVersion(long feedsVersion) {
        this.feedsVersion = feedsVersion;
    }

}
