package com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.AbstractDocumentData;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.AbstractBrandedDocument;

// TODO: Auto-generated Javadoc
/**
 * The Class AbstractBrandedDocumentImpl.
 *
 * @param <E>
 *            the element type
 */
public abstract class AbstractBrandedDocumentImpl<E extends AbstractDocumentData> extends AbstractDocumentImpl<E>
        implements AbstractBrandedDocument<E> {

    /** The brand id. */
    protected Integer brandId;

    /**
     * Instantiates a new abstract branded document impl.
     *
     * @param data
     *            the data
     * @param brandId
     *            the brand id
     */
    public AbstractBrandedDocumentImpl(E data, Integer brandId) {
        super(data);
        this.brandId = brandId;
    }

    /**
     * Instantiates a new abstract branded document impl.
     */
    public AbstractBrandedDocumentImpl() {
        super();
    }

    /**
     * Get brandId.
     *
     * @return the string
     */
    @Override
    public Integer getBrandId() {
        return this.brandId;
    }

    /**
     * Set brandId.
     *
     * @param brandId
     *            the id
     */
    @Override
    public void setBrandId(Integer brandId) {
        this.brandId = brandId;
    }

}
