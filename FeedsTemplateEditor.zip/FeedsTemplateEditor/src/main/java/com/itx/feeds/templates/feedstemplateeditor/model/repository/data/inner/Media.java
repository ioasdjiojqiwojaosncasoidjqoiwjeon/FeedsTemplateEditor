package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

// TODO: Auto-generated Javadoc
/**
 * The Class Media.
 */
public class Media {

    /** The format. */
    private Integer format;

    /** The clazz. */
    private Integer clazz;

    /** The id media. */
    private String idMedia;

    /** The extra info. */
    private ExtraInfo extraInfo;

    /** The timestamp. */
    private Long timestamp;

    /**
     * Instantiates a new media.
     *
     * @param format
     *            the format
     * @param clazz
     *            the clazz
     * @param idMedia
     *            the id media
     * @param extraInfo
     *            the extra info
     * @param timestamp
     *            the timestamp
     */
    public Media(Integer format, Integer clazz, String idMedia, ExtraInfo extraInfo, Long timestamp) {
        super();
        this.format = format;
        this.clazz = clazz;
        this.idMedia = idMedia;
        this.extraInfo = extraInfo;
        this.timestamp = timestamp;
    }

    /**
     * Instantiates a new media.
     */
    public Media() {
        super();
    }

    /**
     * Gets the format.
     *
     * @return the format
     */
    public Integer getFormat() {
        return this.format;
    }

    /**
     * Sets the format.
     *
     * @param format
     *            the new format
     */
    public void setFormat(Integer format) {
        this.format = format;
    }

    /**
     * Gets the clazz.
     *
     * @return the clazz
     */
    public Integer getClazz() {
        return this.clazz;
    }

    /**
     * Sets the clazz.
     *
     * @param clazz
     *            the new clazz
     */
    public void setClazz(Integer clazz) {
        this.clazz = clazz;
    }

    /**
     * Gets the id media.
     *
     * @return the id media
     */
    public String getIdMedia() {
        return this.idMedia;
    }

    /**
     * Sets the id media.
     *
     * @param idMedia
     *            the new id media
     */
    public void setIdMedia(String idMedia) {
        this.idMedia = idMedia;
    }

    /**
     * Gets the extra info.
     *
     * @return the extra info
     */
    public ExtraInfo getExtraInfo() {
        return this.extraInfo;
    }

    /**
     * Sets the extra info.
     *
     * @param extraInfo
     *            the new extra info
     */
    public void setExtraInfo(ExtraInfo extraInfo) {
        this.extraInfo = extraInfo;
    }

    /**
     * Gets the timestamp.
     *
     * @return the timestamp
     */
    public Long getTimestamp() {
        return this.timestamp;
    }

    /**
     * Sets the timestamp.
     *
     * @param timestamp
     *            the new timestamp
     */
    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

}
