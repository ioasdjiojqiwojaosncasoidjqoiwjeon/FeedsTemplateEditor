package com.itx.feeds.templates.feedstemplateeditor.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * Clase que define constantes usadas en el proceso batch.
 * 
 * @author Carlos Antelo
 *
 */
/**
 * Application constants
 *
 */
public class Constants {

    /** INTERNAL_ERROR_CODE = 500. */
    public static final Integer INTERNAL_ERROR_CODE = 500;

    /** INTERNAL_ERROR_MSG = "Internal Error";. */
    public static final String INTERNAL_ERROR_MSG = "Internal Error";

    /** BAD_REQUEST_ERROR_CODE = 400. */
    public static final Integer BAD_REQUEST_ERROR_CODE = 400;

    /** NOT_FOUND_ERROR_CODE = 404. */
    public static final Integer NOT_FOUND_ERROR_CODE = 404;

    /** NOT_FOUND_ERROR_CODE = 405. */
    public static final Integer NOT_ALLOWED = 405;

    /** INVALID_PARAMETER_ERROR_CODE = 409. */
    public static final Integer INVALID_PARAMETER_ERROR_CODE = 409;

    /** NOT_FOUND_CONTENT_CODE = 204. */
    public static final Integer NOT_FOUND_CONTENT_CODE = 204;

    /** OK_CODE = 200. */
    public static final Integer OK_CODE = 200;

    /** The Constant JSON_CONTENT_TYPE. */
    public static final String JSON_CONTENT_TYPE = "application/json";

    /** The Constant VALID_RESPONSES. */
    public static final List<Integer> VALID_RESPONSES = new ArrayList<Integer>(
            Arrays.asList(NOT_FOUND_CONTENT_CODE, OK_CODE));

    /** Ejecución del batch finalizada correctamente. */
    public static final int EXECUTION_OK = 0;

    /** Error interno durante la ejecución del batch. */
    public static final int INTERNAL_ERROR = -1;

    /** Error de conexión a un sistema externo. */
    public static final int CONNECTION_ERROR = -2;

    /** Error de BD. */
    public static final int DATABASE_ERROR = -3;

    /** Error de autorización al conectarse con un sistema externo. */
    public static final int AUTHORIZATION_ERROR = -4;

    /** Error en parámetros de línea de comandos, son inválidos. */
    public static final int INVALID_ARGS_ERROR = -5;

    public static final String DISCARD_EXPORT_OBJECT_SIGNAL = "%DISCARD_OBJECT%";

    /** Constante LENGUAJE INGLES */
    public static final String ENGLISH_CODE_LANG = "en";

    /** The Constant PRODUCTS_COUNT_FOR_REFRESH_PERCENTAGE. */
    public static final String HYPHEN = "-";

    /** The Constant PRODUCTS_COUNT_FOR_REFRESH_PERCENTAGE. */
    public static final String BAR = "|";

    /** Constantes para montar URL's. */
    public static final String FORWARD_SLASH = "/";

    /** Constantes para salto de línea. */
    public static final String UNIX_LINE_SEPARATION = "\n";

    /** Constantes para montar URL's. */
    public static final String SEMICOLON = ";";

    /** Constantes para montar CSV's. */
    public static final String QUOTE_MARK_CSV = "\";\"";

    /** Constantes para montar CSV's. */
    public static final String QUOTE_MARK = "\"";

    /** Constantes para montar CSV's. */
    public static final String BRAND = "brand";

    /** Constantes para montar URL's. */
    public static final String CATEGORY = "category";

    /** Constantes para montar URL's. */
    public static final String STORE = "store";

    /** Constantes para montar URL's. */
    public static final String CATALOG = "catalog";

    /** Constantes para montar URL's. */
    public static final String APPID = "appId";

    /** Constantes para montar URL's. */
    public static final String LANGUAGE = "language";

    /** Constantes para montar URL's. */
    public static final String MOCA = "moca";

    /** Constantes para montar URL's. */
    public static final String PRODUCT_URL = "product";

    /** Constantes para montar URL's. */
    public static final String CONFIGURATION = "configuration";

    /** Constantes para montar URL's. */
    public static final String EXPORT_CONFIGURATION = "exportconfig";

    /** Constantes para montar URL's. */
    public static final String KEY = "key";

    /** Constantes para montar URL's. */
    public static final String EXPORT_TYPE = "exporttype";

    /** Constantes para montar URL's. */
    public static final String JSON_EXTENSION = "JSON";

    /** Constantes para montar URL's. */
    public static final String CSV_EXTENSION = "CSV";

    /** Constantes para montar URL's. */
    public static final String JSON_OBJECT_INSIDE_ARRAY_SEPARATOR = ",";

    /** Constantes para montar URL's. */
    public static final String JSON_OBJECT_FINAL_ARRAY_CHAR = "]";

    /** Constantes para montar URL's. */
    public static final String IMAGE_EXTENSION_PART = ".jpg?t=";

    /** Constantes para montar URL's. */
    public static final String NEW_STRING = "NEW";

    /** Constantes para montar URL's. */
    public static final String HTTPS = "https://";

    /** The Constant MOCA_BUNDLE. */
    public static final String BUNDLE_BEAN = "BundleBean";

    /** The Constant PRODUCT_BEAN. */
    public static final String PRODUCT_BEAN = "ProductBean";

    /** The Constant BUNDLE. */
    public static final String BUNDLE = "BUNDLE";

    /** The Constant BUNDLE. */
    public static final String MOCACO = "MOCACO";

    /** The Constant BUNDLE. */
    public static final String GRUCACO = "GRUCACO";

    /** The Constant BUNDLE. */
    public static final String PRODUCT = "PRODUCT";

    /** The Constant ESTILISMO. */
    public static final String ESTILISMO = "ESTILISMO";

    /** Constantes para politica de reintentos (Numero de intentos máximos de llamadas a API). */
    public static final int MAX_ATTEMPS_TO_CALL_API = 5;

    /** Constantes para politica de reintentos (tiempo de espera en milisegundos). */
    public static final int SLEEP_MILIS_PER_TRY = 2000;

    /** Constantes para politica de reintentos llamadas ajenas al Repository (tiempo de espera en milisegundos). */
    public static final int SLEEP_MILIS_PER_TRY_EXTERNAL = 4000;

    /** * Errors limit. */
    public static final int ERRORS_LIMIT_TO_END_EXECUTION = 50;

    /** Constants for configuration. */
    public static final String EXPORT_MOCAS_WITHOUT_STOCK = "EXPORT_MOCAS_WITHOUT_STOCK";

    /** Constants for configuration. */
    public static final String COUNTRY_CODE_MAPPING = "COUNTRY_CODE_MAPPING";

    /** Constants for configuration. */
    public static final String IMAGE_URL = "Image_suffix";

    /** Constants for configuration document. */
    public static final String IMAGE_SMALL_URL = "Image_small_suffix";

    /** Constants for configuration document. */
    public static final String IMAGE_MEDIUM_URL = "Image_medium_suffix";

    /** Constants for configuration document. */
    public static final String IMAGE_BIG_URL = "Image_big_suffix";

    /** Constants for configuration document. */
    public static final String IMAGE_SILHOUETTED_URL = "Image_silhouetted_suffix";

    /** Constants for configuration document. */
    public static final String DELIVERY_COSTS = "Delivery_costs";

    /** Constants for configuration document. */
    public static final String DELIVERY_TIME = "Delivery_time";

    /** Constants for configuration document. */
    public static final String DELIVERY_DESC = "Delivery_description";

    /** Constants for configuration document. */
    public static final String WARRANTY = "Warranty";

    /** Constants for configuration document. */
    public static final String URL_STRATEGY = "URL_Strategy";

    /** Constants for configuration Lengow CSV Files. */
    public static final String LANGUAGE_FILES_MODE = "_LANGUAGE_FILES_MODE";

    /** Constants for configuration Languages to export. */
    public static final String LANGUAGES_TO_EXPORT = "_LANGUAGES_TO_EXPORT";

    /** Constants for configuration Lengow CSV Files. */
    public static final String PRODUCT_URL_HOST = "PRODUCT_URL_HOST";

    /** Constants for configuration Lengow CSV Files. */
    public static final String IMAGE_URL_HOST = "IMAGE_URL_HOST";

    /** Constants for configuration Colbenson Files. */
    public static final String FILENAME = "_filename";

    /** Constants for configuration Colbenson Files. */
    public static final String TEMPORARY_FILES_PATH = "TEMPORARY_FILES_PATH";

    /** Constants for configuration exportPath. */
    public static final String EXPORT_FILES_PATH = "EXPORT_FILE_PATH_";

    /** Configuration values. */
    public static final String PRODUCT_URL_STRATEGY = "ProductUrl";

    /** Configuration values. */
    public static final String ALL_LANGUAGES = "ALL";

    /** Constants for configuration COLBENSON JSON Files. */
    public static final String URL_TOKEN = "URL_TOKEN";

    /** Configuration values. */
    public static final String PRICE_FORMAT = "PRICE_FORMAT";

    /** Configuration threads num */
    public static final int NUM_PRODUCTS_PRODUCER_THREADS = 32;

    /** Configuration threads num */
    public static final int NUM_CATEGORIES_LIST_PRODUCER_THREADS = 16;

}
