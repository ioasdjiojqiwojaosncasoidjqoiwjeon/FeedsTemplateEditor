package com.itx.feeds.templates.feedstemplateeditor.export;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.javatuples.Quartet;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.Configuration;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.TemplateConfiguration;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.TemplateContent;

import freemarker.cache.StringTemplateLoader;
import freemarker.core.JSONOutputFormat;
import freemarker.core.ParseException;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.Template;
import freemarker.template.TemplateNotFoundException;

// TODO: Auto-generated Javadoc
/**
 * Configuration Utilities.
 */
public class ConfigurationUtils {

	/**
	 * Load config map.
	 *
	 * @param configurations the configurations
	 * @param brandId        the brand id
	 * @return Map with all configuration which are applicable on the brandId
	 */
	public static Map<Quartet<String, Integer, Integer, Integer>, String> loadConfigMap(
			List<Configuration> configurations, Integer brandId) {

		Map<Quartet<String, Integer, Integer, Integer>, String> mapConfig = new HashMap<Quartet<String, Integer, Integer, Integer>, String>();

		for (Configuration configuration : configurations) {
			if (configuration.getBrandId() == null || configuration.getBrandId().equals(brandId)) {
				Quartet<String, Integer, Integer, Integer> keyConfigMap = new Quartet<String, Integer, Integer, Integer>(
						configuration.getKey(), configuration.getBrandId(), configuration.getStoreId(),
						configuration.getLanguageId());

				mapConfig.put(keyConfigMap, configuration.getData().getValue());
			}
		}

		return mapConfig;
	}

	/**
	 * Gets the config value.
	 *
	 * @param key        the key
	 * @param brandId    the brand id
	 * @param storeId    the store id
	 * @param languageId the language id
	 * @param configMap  the config map
	 * @return Configuration value for the parameters.
	 */
	public static String getConfigValue(String key, Integer brandId, Integer storeId, Integer languageId,
			Map<Quartet<String, Integer, Integer, Integer>, String> configMap) {
		String configValue;
		Quartet<String, Integer, Integer, Integer> keyConfigMap = new Quartet<String, Integer, Integer, Integer>(key,
				brandId, storeId, languageId);

		if (configMap.containsKey(keyConfigMap)) {
			configValue = configMap.get(keyConfigMap);
		} else {
			if (languageId != null) {
				configValue = getConfigValue(key, brandId, storeId, null, configMap);
			} else if (storeId != null) {
				configValue = getConfigValue(key, brandId, null, null, configMap);
			} else if (brandId != null) {
				configValue = getConfigValue(key, null, null, null, configMap);
			} else {
				configValue = "";
			}
		}
		return configValue;
	}

	/**
	 * Gets the FreeMarkerTemplate Map.
	 *
	 * @param templateConfigurations the templateConfigurations
	 * @param templatesContent       the templatesContent
	 * @return Map with key storeId, Free marker template.
	 * @throws IOException 
	 */
	public static Map<Integer, TemplateConfig> loadTemplateMap(List<TemplateConfiguration> templateConfigurations,
			List<TemplateContent> templatesContent) throws IOException {
		Map<Integer, TemplateConfig> templateMap = new HashMap<Integer, TemplateConfig>();
		Map<String, String> templateContentMap = loadTemplateContentMap(templatesContent);

		if (templateContentMap != null) {
			for (TemplateConfiguration templateConfiguration : templateConfigurations) {
				Integer storeId = templateConfiguration.getStoreId();
				TemplateConfig template = loadTemplateConfig(templateConfiguration, templateContentMap);

				templateMap.put(storeId, template);
			}
			return templateMap;
		}

		return null;
	}

	/**
	 * @param storeId
	 * @param templateMap
	 * @return Template
	 */
	public static Template getTemplateByStoreId(Integer storeId, Map<Integer, TemplateConfig> templateMap) {
		if (templateMap.containsKey(storeId)) {
			return templateMap.get(storeId).getTemplate();
		} else {
			return templateMap.get(null).getTemplate();
		}
	}

	/**
	 * Gets the FreeMarkerTemplate Map.
	 *
	 * @param templateConfigurations the templateConfigurations
	 * @return Map with key storeId, templateConfiguration.
	 */
	private static Map<String, String> loadTemplateContentMap(List<TemplateContent> templatesContent) {
		Map<String, String> templatesContentMap = new HashMap<String, String>();

		for (TemplateContent templateContent : templatesContent) {
			templatesContentMap.put(templateContent.getTemplateName(), templateContent.getData().getContent()
					.replaceAll("\n", "").replaceAll("\t", "").replaceAll("\r", ""));
		}

		return templatesContentMap;
	}

	/**
	 * Gets the template.
	 *
	 * @param templateConfiguration
	 * @param brandId               the brand id
	 * @return Configuration value for the parameters.
	 * @throws IOException 
	 * @throws ParseException 
	 * @throws MalformedTemplateNameException 
	 * @throws TemplateNotFoundException 
	 */
	private static TemplateConfig loadTemplateConfig(TemplateConfiguration templateConfiguration,
			Map<String, String> templatesContentMap) throws IOException {
		TemplateConfig configTemplate = new TemplateConfig();
		freemarker.template.Configuration configurationTemplate = new freemarker.template.Configuration(
				freemarker.template.Configuration.VERSION_2_3_27);
		configurationTemplate.setDefaultEncoding("UTF-8");
		configurationTemplate.setOutputFormat(JSONOutputFormat.INSTANCE);
		configurationTemplate
				.setAutoEscapingPolicy(freemarker.template.Configuration.ENABLE_IF_SUPPORTED_AUTO_ESCAPING_POLICY);

		StringTemplateLoader stringLoader = new StringTemplateLoader();
		for (String templateName : templateConfiguration.getData().getTemplateNamesList()) {
			if (templatesContentMap.containsKey(templateName)) {
				stringLoader.putTemplate(templateName, templatesContentMap.get(templateName));
			}
		}
		// We have to load the mainTemplate too
		if (templatesContentMap.containsKey(templateConfiguration.getData().getMainTemplate())) {
			stringLoader.putTemplate(templateConfiguration.getData().getMainTemplate(),
					templatesContentMap.get(templateConfiguration.getData().getMainTemplate()));
		}

		configurationTemplate.setTemplateLoader(stringLoader);

		configTemplate.setHeader(templateConfiguration.getData().getHeader());
		configTemplate.setFooter(templateConfiguration.getData().getFooter());
		configTemplate
				.setTemplate(configurationTemplate.getTemplate(templateConfiguration.getData().getMainTemplate()));
		return configTemplate;
	}

}
