package com.itx.feeds.templates.feedstemplateeditor.model.repository.document;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.AbstractDocumentData;

// TODO: Auto-generated Javadoc
/**
 * The Interface AbstractDocument.
 *
 * @param <E>
 *            the element type
 */
public interface AbstractDocument<E extends AbstractDocumentData> {

    /**
     * Gets the data.
     *
     * @return the data
     */
    E getData();

    /**
     * Sets the data.
     *
     * @param data
     *            the new data
     */
    void setData(E data);

}
