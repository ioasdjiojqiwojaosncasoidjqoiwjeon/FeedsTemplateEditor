package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl;

import java.util.List;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Catalog;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Locale;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Promotion;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.SupportedLanguage;


// TODO: Auto-generated Javadoc
/**
 * The Class StoreData.
 */
public class StoreData extends AbstractDocumentDataImpl {

    /** The country code. */
    private String countryCode;

    /** The hostname. */
    private String hostname;

    /** The is open for sale. */
    private boolean isOpenForSale;

    /** The is open for sale android. */
    private boolean isOpenForSaleAndroid;

    /** The is open for sale ios. */
    private boolean isOpenForSaleIOS;

    /** The type. */
    private Integer type;

    /** The supported language. */
    private List<SupportedLanguage> supportedLanguage;

    /** The catalogs. */
    private List<Catalog> catalogs;

    /** The locale. */
    private Locale locale;

    /** The ffmcenter. */
    private long ffmcenter;

    /** The store default language id. */
    private Integer storeDefaultLanguageId;

    /** The SE ocountry code. */
    private String SEOcountryCode;

    /** The image base url. */
    private String imageBaseUrl;

    private List<Promotion> promotions;

    /**
     * Instantiates a new store data.
     *
     * @param countryCode
     *            the country code
     * @param hostname
     *            the hostname
     * @param isOpenForSale
     *            the is open for sale
     * @param isOpenForSaleAndroid
     *            the is open for sale android
     * @param isOpenForSaleIOS
     *            the is open for sale ios
     * @param type
     *            the type
     * @param supportedLanguage
     *            the supported language
     * @param catalogs
     *            the catalogs
     * @param locale
     *            the locale
     * @param ffmcenter
     *            the ffmcenter
     * @param storeDefaultLanguageId
     *            the store default language id
     * @param sEOcountryCode
     *            the s e ocountry code
     * @param imageBaseUrl
     *            the image base url
     */
    public StoreData(String countryCode, String hostname, boolean isOpenForSale, boolean isOpenForSaleAndroid,
            boolean isOpenForSaleIOS, Integer type, List<SupportedLanguage> supportedLanguage, List<Catalog> catalogs,
            Locale locale, long ffmcenter, Integer storeDefaultLanguageId, String sEOcountryCode, String imageBaseUrl,
            List<Promotion> promotions) {
        super();
        this.countryCode = countryCode;
        this.hostname = hostname;
        this.isOpenForSale = isOpenForSale;
        this.isOpenForSaleAndroid = isOpenForSaleAndroid;
        this.isOpenForSaleIOS = isOpenForSaleIOS;
        this.type = type;
        this.supportedLanguage = supportedLanguage;
        this.catalogs = catalogs;
        this.locale = locale;
        this.ffmcenter = ffmcenter;
        this.storeDefaultLanguageId = storeDefaultLanguageId;
        this.SEOcountryCode = sEOcountryCode;
        this.imageBaseUrl = imageBaseUrl;
        this.promotions = promotions;
    }

    /**
     * Instantiates a new store data.
     */
    public StoreData() {
        super();
    }

    /**
     * Gets the country code.
     *
     * @return the country code
     */
    public String getCountryCode() {
        return this.countryCode;
    }

    /**
     * Sets the country code.
     *
     * @param countryCode
     *            the new country code
     */
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    /**
     * Gets the hostname.
     *
     * @return the hostname
     */
    public String getHostname() {
        return this.hostname;
    }

    /**
     * Sets the hostname.
     *
     * @param hostname
     *            the new hostname
     */
    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    /**
     * Checks if is open for sale.
     *
     * @return true, if is open for sale
     */
    public boolean isOpenForSale() {
        return this.isOpenForSale;
    }

    /**
     * Sets the open for sale.
     *
     * @param isOpenForSale
     *            the new open for sale
     */
    public void setOpenForSale(boolean isOpenForSale) {
        this.isOpenForSale = isOpenForSale;
    }

    /**
     * Checks if is open for sale android.
     *
     * @return true, if is open for sale android
     */
    public boolean isOpenForSaleAndroid() {
        return this.isOpenForSaleAndroid;
    }

    /**
     * Sets the open for sale android.
     *
     * @param isOpenForSaleAndroid
     *            the new open for sale android
     */
    public void setOpenForSaleAndroid(boolean isOpenForSaleAndroid) {
        this.isOpenForSaleAndroid = isOpenForSaleAndroid;
    }

    /**
     * Checks if is open for sale ios.
     *
     * @return true, if is open for sale ios
     */
    public boolean isOpenForSaleIOS() {
        return this.isOpenForSaleIOS;
    }

    /**
     * Sets the open for sale ios.
     *
     * @param isOpenForSaleIOS
     *            the new open for sale ios
     */
    public void setOpenForSaleIOS(boolean isOpenForSaleIOS) {
        this.isOpenForSaleIOS = isOpenForSaleIOS;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public Integer getType() {
        return this.type;
    }

    /**
     * Sets the type.
     *
     * @param type
     *            the new type
     */
    public void setType(Integer type) {
        this.type = type;
    }

    /**
     * Gets the supported language.
     *
     * @return the supported language
     */
    public List<SupportedLanguage> getSupportedLanguage() {
        return this.supportedLanguage;
    }

    /**
     * Sets the supported language.
     *
     * @param supportedLanguage
     *            the new supported language
     */
    public void setSupportedLanguage(List<SupportedLanguage> supportedLanguage) {
        this.supportedLanguage = supportedLanguage;
    }

    /**
     * Gets the catalogs.
     *
     * @return the catalogs
     */
    public List<Catalog> getCatalogs() {
        return this.catalogs;
    }

    /**
     * Sets the catalogs.
     *
     * @param catalogs
     *            the new catalogs
     */
    public void setCatalogs(List<Catalog> catalogs) {
        this.catalogs = catalogs;
    }

    /**
     * Gets the locale.
     *
     * @return the locale
     */
    public Locale getLocale() {
        return this.locale;
    }

    /**
     * Sets the locale.
     *
     * @param locale
     *            the new locale
     */
    public void setLocale(Locale locale) {
        this.locale = locale;
    }

    /**
     * Gets the ffmcenter.
     *
     * @return the ffmcenter
     */
    public long getFfmcenter() {
        return this.ffmcenter;
    }

    /**
     * Sets the ffmcenter.
     *
     * @param ffmcenter
     *            the new ffmcenter
     */
    public void setFfmcenter(long ffmcenter) {
        this.ffmcenter = ffmcenter;
    }

    /**
     * Gets the store default language id.
     *
     * @return the store default language id
     */
    public Integer getStoreDefaultLanguageId() {
        return this.storeDefaultLanguageId;
    }

    /**
     * Sets the store default language id.
     *
     * @param storeDefaultLanguageId
     *            the new store default language id
     */
    public void setStoreDefaultLanguageId(Integer storeDefaultLanguageId) {
        this.storeDefaultLanguageId = storeDefaultLanguageId;
    }

    /**
     * Gets the SE ocountry code.
     *
     * @return the SE ocountry code
     */
    public String getSEOcountryCode() {
        return this.SEOcountryCode;
    }

    /**
     * Sets the SE ocountry code.
     *
     * @param sEOcountryCode
     *            the new SE ocountry code
     */
    public void setSEOcountryCode(String sEOcountryCode) {
        this.SEOcountryCode = sEOcountryCode;
    }

    /**
     * Gets the image base url.
     *
     * @return the image base url
     */
    public String getImageBaseUrl() {
        return this.imageBaseUrl;
    }

    /**
     * Sets the image base url.
     *
     * @param imageBaseUrl
     *            the new image base url
     */
    public void setImageBaseUrl(String imageBaseUrl) {
        this.imageBaseUrl = imageBaseUrl;
    }

    /**
     * @return the promotions
     */
    public List<Promotion> getPromotions() {
        return promotions;
    }

    /**
     * @param promotions
     *            the promotions to set
     */
    public void setPromotions(List<Promotion> promotions) {
        this.promotions = promotions;
    }

}
