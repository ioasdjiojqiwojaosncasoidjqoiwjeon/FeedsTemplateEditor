package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.Date;
import java.util.List;

/**
 * The Class Price.
 */
public class Price {

    /** The price list. */
    private List<String> priceList;

    /** The current price. */
    private String currentPrice;

    /** The old price. */
    private String oldPrice;

    private Date startDate;

    private Date endDate;

    private Date lastUpdateDate;

    private Integer precedence;

    private Boolean isVIP;

    private Integer promotionId;

    /**
     * @param priceList
     * @param currentPrice
     * @param oldPrice
     * @param startDate
     * @param endDate
     * @param lastUpdateDate
     * @param precedence
     */
    public Price(List<String> priceList, String currentPrice, String oldPrice, Date startDate, Date endDate,
            Date lastUpdateDate, Integer precedence, Boolean isVIP, Integer promotionId) {
        super();
        this.priceList = priceList;
        this.currentPrice = currentPrice;
        this.oldPrice = oldPrice;
        this.startDate = startDate;
        this.endDate = endDate;
        this.lastUpdateDate = lastUpdateDate;
        this.precedence = precedence;
        this.isVIP = isVIP;
        this.promotionId = promotionId;
    }

    /**
     * Instantiates a new price.
     */
    public Price() {
        super();
    }

    /**
     * Gets the price list.
     *
     * @return the price list
     */
    public List<String> getPriceList() {
        return this.priceList;
    }

    /**
     * Sets the price list.
     *
     * @param priceList
     *            the new price list
     */
    public void setPriceList(List<String> priceList) {
        this.priceList = priceList;
    }

    /**
     * Gets the current price.
     *
     * @return the current price
     */
    public String getCurrentPrice() {
        return this.currentPrice;
    }

    /**
     * Sets the current price.
     *
     * @param currentPrice
     *            the new current price
     */
    public void setCurrentPrice(String currentPrice) {
        this.currentPrice = currentPrice;
    }

    /**
     * Gets the old price.
     *
     * @return the old price
     */
    public String getOldPrice() {
        return this.oldPrice;
    }

    /**
     * Sets the old price.
     *
     * @param oldPrice
     *            the new old price
     */
    public void setOldPrice(String oldPrice) {
        this.oldPrice = oldPrice;
    }

    /**
     * @return date
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * @param startDate
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * @return date
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * @param endDate
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * @return the lastupdateDate
     */
    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * @param lastUpdateDate
     *            the lastupdateDate to set
     */
    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    /**
     * @return integer
     */
    public Integer getPrecedence() {
        return precedence;
    }

    /**
     * @param precedence
     */
    public void setPrecedence(Integer precedence) {
        this.precedence = precedence;
    }

    /**
     * @return the isVIP
     */
    public Boolean getIsVIP() {
        return isVIP;
    }

    /**
     * @param isVIP
     *            the isVIP to set
     */
    public void setIsVIP(Boolean isVIP) {
        this.isVIP = isVIP;
    }

    /**
     * @return the promotionId
     */
    public Integer getPromotionId() {
        return promotionId;
    }

    /**
     * @param promotionId
     *            the promotionId to set
     */
    public void setPromotionId(Integer promotionId) {
        this.promotionId = promotionId;
    }

}
