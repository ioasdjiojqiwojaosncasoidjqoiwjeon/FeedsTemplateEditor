package com.itx.feeds.templates.feedstemplateeditor.model.repository.document;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.AbstractDocumentData;

// TODO: Auto-generated Javadoc
/**
 * The Interface AbstractBrandedVersionedDocument.
 *
 * @param <E>
 *            the element type
 */
public interface AbstractBrandedVersionedDocument<E extends AbstractDocumentData> extends AbstractBrandedDocument<E> {

    /**
     * Gets the feeds version.
     *
     * @return the feeds version
     */
    long getFeedsVersion();

    /**
     * Sets the feeds version.
     *
     * @param feedsVersion
     *            the new feeds version
     */
    void setFeedsVersion(long feedsVersion);

}
