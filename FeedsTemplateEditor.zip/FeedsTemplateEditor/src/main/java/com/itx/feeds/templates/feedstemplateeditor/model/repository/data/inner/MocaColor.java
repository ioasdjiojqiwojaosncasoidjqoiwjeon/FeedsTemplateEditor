package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

// TODO: Auto-generated Javadoc
/**
 * The Class MocaColor.
 */
public class MocaColor {

    /** The id color. */
    private String idColor;

    /** The is continuity. */
    private Boolean isContinuity;

    /** The image. */
    private Image image;

    /**
     * Instantiates a new moca color.
     *
     * @param idColor
     *            the id color
     * @param isContinuity
     *            the is continuity
     * @param image
     *            the image
     */
    public MocaColor(String idColor, Image image) {
        super();
        this.idColor = idColor;
        this.image = image;
    }

    /**
     * Instantiates a new moca color.
     */
    public MocaColor() {
        super();
    }

    /**
     * Gets the id color.
     *
     * @return the id color
     */
    public String getIdColor() {
        return this.idColor;
    }

    /**
     * Sets the id color.
     *
     * @param idColor
     *            the new id color
     */
    public void setIdColor(String idColor) {
        this.idColor = idColor;
    }

    /**
     * Gets the image.
     *
     * @return the image
     */
    public Image getImage() {
        return this.image;
    }

    /**
     * Sets the image.
     *
     * @param image
     *            the new image
     */
    public void setImage(Image image) {
        this.image = image;
    }

    /**
     * @return Boolean
     */
    public Boolean getIsContinuity() {
        return isContinuity;
    }

    /**
     * @param isContinuity
     */
    public void setIsContinuity(Boolean isContinuity) {
        this.isContinuity = isContinuity;
    }

}
