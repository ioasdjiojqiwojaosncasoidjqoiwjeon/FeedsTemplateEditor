package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl;

import java.util.List;

/**
 * @author luisvpi
 *
 */
public class TemplateConfigurationData extends AbstractDocumentDataImpl {

    /** The templates. */
    private String mainTemplate;

    /** The templates. */
    private List<String> templateNamesList;

    /** The header. */
    private String header;

    private String footer;

    /**
     * Instantiates a new feeds configuration data.
     * 
     * @param header
     * @param mainTemplate
     * @param templateNamesList
     */
    public TemplateConfigurationData(String header, String mainTemplate, List<String> templateNamesList,
            String footer) {
        this.header = header;
        this.templateNamesList = templateNamesList;
        this.mainTemplate = mainTemplate;
        this.footer = footer;
    }

    /**
     * Instantiates a new Mapper Template Configuration data.
     */
    public TemplateConfigurationData() {
        super();
    }

    /**
     * Gets the getHeader.
     *
     * @return the getHeader
     */
    public String getHeader() {
        return header;
    }

    /**
     * Sets the header.
     *
     * @param header
     *            the new header
     */
    public void setHeader(String header) {
        this.header = header;
    }

    /**
     * Gets the main template.
     *
     * @return the main template
     */
    public String getMainTemplate() {
        return mainTemplate;
    }

    /**
     * Sets the mainTemplate.
     *
     * @param mainTemplate
     *            the new mainTemplate
     */
    public void setMainTemplate(String mainTemplate) {
        this.mainTemplate = mainTemplate;
    }

    /**
     * Gets the templates.
     *
     * @return the templates
     */
    public List<String> getTemplateNamesList() {
        return this.templateNamesList;
    }

    /**
     * Sets the templateNamesList.
     *
     * @param templateNamesList
     *            the new templateNamesList
     */
    public void setTemplateNamesList(List<String> templateNamesList) {
        this.templateNamesList = templateNamesList;
    }

    /**
     * @return the footer
     */
    public String getFooter() {
        return footer;
    }

    /**
     * @param footer
     *            the footer to set
     */
    public void setFooter(String footer) {
        this.footer = footer;
    }

}