package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class MocaI18nColor.
 */
public class MocaI18nColor {

    /** The id color. */
    private String idColor;

    /** The composition. */
    private List<CompositionWrapper> composition;

    /** The composition by zone. */
    private List<CompositionByZone> compositionByZone;

    /** The care. */
    private List<Care> care;

    /** The name. */
    private String name;

    /** The fields. */
    private List<KeyValueField> fields;

    /**
     * Instantiates a new moca i18n color.
     *
     * @param idColor
     *            the id color
     * @param composition
     *            the composition
     * @param compositionByZone
     *            the composition by zone
     * @param care
     *            the care
     * @param name
     *            the name
     * @param fields
     *            the fields
     */
    public MocaI18nColor(String idColor, List<CompositionWrapper> composition,
            List<CompositionByZone> compositionByZone, List<Care> care, String name, List<KeyValueField> fields) {
        super();
        this.idColor = idColor;
        this.composition = composition;
        this.compositionByZone = compositionByZone;
        this.care = care;
        this.name = name;
        this.fields = fields;
    }

    /**
     * Instantiates a new moca i18n color.
     */
    public MocaI18nColor() {
        super();
    }

    /**
     * Gets the id color.
     *
     * @return the id color
     */
    public String getIdColor() {
        return this.idColor;
    }

    /**
     * Sets the id color.
     *
     * @param idColor
     *            the new id color
     */
    public void setIdColor(String idColor) {
        this.idColor = idColor;
    }

    /**
     * Gets the composition.
     *
     * @return the composition
     */
    public List<CompositionWrapper> getComposition() {
        return this.composition;
    }

    /**
     * Sets the composition.
     *
     * @param composition
     *            the new composition
     */
    public void setComposition(List<CompositionWrapper> composition) {
        this.composition = composition;
    }

    /**
     * Gets the composition by zone.
     *
     * @return the composition by zone
     */
    public List<CompositionByZone> getCompositionByZone() {
        return this.compositionByZone;
    }

    /**
     * Sets the composition by zone.
     *
     * @param compositionByZone
     *            the new composition by zone
     */
    public void setCompositionByZone(List<CompositionByZone> compositionByZone) {
        this.compositionByZone = compositionByZone;
    }

    /**
     * Gets the care.
     *
     * @return the care
     */
    public List<Care> getCare() {
        return this.care;
    }

    /**
     * Sets the care.
     *
     * @param care
     *            the new care
     */
    public void setCare(List<Care> care) {
        this.care = care;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the name.
     *
     * @param name
     *            the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the fields.
     *
     * @return the fields
     */
    public List<KeyValueField> getFields() {
        return this.fields;
    }

    /**
     * Sets the fields.
     *
     * @param fields
     *            the new fields
     */
    public void setFields(List<KeyValueField> fields) {
        this.fields = fields;
    }

}
