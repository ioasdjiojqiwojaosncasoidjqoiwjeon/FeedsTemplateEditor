package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl;

import java.util.List;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Host;


// TODO: Auto-generated Javadoc
/**
 * The Class BrandData.
 */
public class BrandData extends AbstractDocumentDataImpl {

    /** The name. */
    private String name;

    /** The host. */
    private List<Host> host;

    /** The app id. */
    private List<Integer> appId;

    /**
     * Instantiates a new brand data.
     */
    public BrandData() {
        super();
    }

    /**
     * Instantiates a new brand data.
     *
     * @param name
     *            the name
     * @param host
     *            the host
     * @param appId
     *            the app id
     */
    public BrandData(String name, List<Host> host, List<Integer> appId) {
        super();
        this.name = name;
        this.host = host;
        this.appId = appId;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the name.
     *
     * @param name
     *            the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the host.
     *
     * @return the host
     */
    public List<Host> getHost() {
        return this.host;
    }

    /**
     * Sets the host.
     *
     * @param host
     *            the new host
     */
    public void setHost(List<Host> host) {
        this.host = host;
    }

    /**
     * Gets the app id.
     *
     * @return the app id
     */
    public List<Integer> getAppId() {
        return this.appId;
    }

    /**
     * Sets the app id.
     *
     * @param appId
     *            the new app id
     */
    public void setAppId(List<Integer> appId) {
        this.appId = appId;
    }

}
