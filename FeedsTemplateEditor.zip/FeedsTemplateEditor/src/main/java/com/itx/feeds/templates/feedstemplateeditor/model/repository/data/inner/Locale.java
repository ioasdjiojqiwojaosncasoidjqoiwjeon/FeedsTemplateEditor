package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

// TODO: Auto-generated Javadoc
/**
 * The Class Locale.
 */
public class Locale {

    /** The lang id. */
    private int langId;

    /** The currency code. */
    private String currencyCode;

    /** The currency decimals. */
    private int currencyDecimals;

    /** The currency format pos. */
    private String currencyFormatPos;

    /** The currency format neg. */
    private String currencyFormatNeg;

    /** The currency symbol. */
    private String currencySymbol;

    /** The currency format pos html. */
    private String currencyFormatPosHtml;

    /** The currency format neg html. */
    private String currencyFormatNegHtml;

    /** The currency symbol html. */
    private String currencySymbolHtml;

    /** The currencygrouping char. */
    private String currencygroupingChar;

    /** The currencydecimal char. */
    private String currencydecimalChar;

    /** The currencygrouping char html. */
    private String currencygroupingCharHtml;

    /** The currencydecimal char html. */
    private String currencydecimalCharHtml;

    /**
     * Instantiates a new locale.
     *
     * @param langId
     *            the lang id
     * @param currencyCode
     *            the currency code
     * @param currencyDecimals
     *            the currency decimals
     * @param currencyFormatPos
     *            the currency format pos
     * @param currencyFormatNeg
     *            the currency format neg
     * @param currencySymbol
     *            the currency symbol
     * @param currencyFormatPosHtml
     *            the currency format pos html
     * @param currencyFormatNegHtml
     *            the currency format neg html
     * @param currencySymbolHtml
     *            the currency symbol html
     * @param currencygroupingChar
     *            the currencygrouping char
     * @param currencydecimalChar
     *            the currencydecimal char
     * @param currencygroupingCharHtml
     *            the currencygrouping char html
     * @param currencydecimalCharHtml
     *            the currencydecimal char html
     */
    public Locale(int langId, String currencyCode, int currencyDecimals, String currencyFormatPos,
            String currencyFormatNeg, String currencySymbol, String currencyFormatPosHtml, String currencyFormatNegHtml,
            String currencySymbolHtml, String currencygroupingChar, String currencydecimalChar,
            String currencygroupingCharHtml, String currencydecimalCharHtml) {
        super();
        this.langId = langId;
        this.currencyCode = currencyCode;
        this.currencyDecimals = currencyDecimals;
        this.currencyFormatPos = currencyFormatPos;
        this.currencyFormatNeg = currencyFormatNeg;
        this.currencySymbol = currencySymbol;
        this.currencyFormatPosHtml = currencyFormatPosHtml;
        this.currencyFormatNegHtml = currencyFormatNegHtml;
        this.currencySymbolHtml = currencySymbolHtml;
        this.currencygroupingChar = currencygroupingChar;
        this.currencydecimalChar = currencydecimalChar;
        this.currencygroupingCharHtml = currencygroupingCharHtml;
        this.currencydecimalCharHtml = currencydecimalCharHtml;
    }

    /**
     * Instantiates a new locale.
     */
    public Locale() {
        super();
    }

    /**
     * Gets the lang id.
     *
     * @return the lang id
     */
    public int getLangId() {
        return this.langId;
    }

    /**
     * Sets the lang id.
     *
     * @param langId
     *            the new lang id
     */
    public void setLangId(int langId) {
        this.langId = langId;
    }

    /**
     * Gets the currency code.
     *
     * @return the currency code
     */
    public String getCurrencyCode() {
        return this.currencyCode;
    }

    /**
     * Sets the currency code.
     *
     * @param currencyCode
     *            the new currency code
     */
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    /**
     * Gets the currency decimals.
     *
     * @return the currency decimals
     */
    public int getCurrencyDecimals() {
        return this.currencyDecimals;
    }

    /**
     * Sets the currency decimals.
     *
     * @param currencyDecimals
     *            the new currency decimals
     */
    public void setCurrencyDecimals(int currencyDecimals) {
        this.currencyDecimals = currencyDecimals;
    }

    /**
     * Gets the currency format pos.
     *
     * @return the currency format pos
     */
    public String getCurrencyFormatPos() {
        return this.currencyFormatPos;
    }

    /**
     * Sets the currency format pos.
     *
     * @param currencyFormatPos
     *            the new currency format pos
     */
    public void setCurrencyFormatPos(String currencyFormatPos) {
        this.currencyFormatPos = currencyFormatPos;
    }

    /**
     * Gets the currency format neg.
     *
     * @return the currency format neg
     */
    public String getCurrencyFormatNeg() {
        return this.currencyFormatNeg;
    }

    /**
     * Sets the currency format neg.
     *
     * @param currencyFormatNeg
     *            the new currency format neg
     */
    public void setCurrencyFormatNeg(String currencyFormatNeg) {
        this.currencyFormatNeg = currencyFormatNeg;
    }

    /**
     * Gets the currency symbol.
     *
     * @return the currency symbol
     */
    public String getCurrencySymbol() {
        return this.currencySymbol;
    }

    /**
     * Sets the currency symbol.
     *
     * @param currencySymbol
     *            the new currency symbol
     */
    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }

    /**
     * Gets the currency format pos html.
     *
     * @return the currency format pos html
     */
    public String getCurrencyFormatPosHtml() {
        return this.currencyFormatPosHtml;
    }

    /**
     * Sets the currency format pos html.
     *
     * @param currencyFormatPosHtml
     *            the new currency format pos html
     */
    public void setCurrencyFormatPosHtml(String currencyFormatPosHtml) {
        this.currencyFormatPosHtml = currencyFormatPosHtml;
    }

    /**
     * Gets the currency format neg html.
     *
     * @return the currency format neg html
     */
    public String getCurrencyFormatNegHtml() {
        return this.currencyFormatNegHtml;
    }

    /**
     * Sets the currency format neg html.
     *
     * @param currencyFormatNegHtml
     *            the new currency format neg html
     */
    public void setCurrencyFormatNegHtml(String currencyFormatNegHtml) {
        this.currencyFormatNegHtml = currencyFormatNegHtml;
    }

    /**
     * Gets the currency symbol html.
     *
     * @return the currency symbol html
     */
    public String getCurrencySymbolHtml() {
        return this.currencySymbolHtml;
    }

    /**
     * Sets the currency symbol html.
     *
     * @param currencySymbolHtml
     *            the new currency symbol html
     */
    public void setCurrencySymbolHtml(String currencySymbolHtml) {
        this.currencySymbolHtml = currencySymbolHtml;
    }

    /**
     * Gets the currencygrouping char.
     *
     * @return the currencygrouping char
     */
    public String getCurrencygroupingChar() {
        return this.currencygroupingChar;
    }

    /**
     * Sets the currencygrouping char.
     *
     * @param currencygroupingChar
     *            the new currencygrouping char
     */
    public void setCurrencygroupingChar(String currencygroupingChar) {
        this.currencygroupingChar = currencygroupingChar;
    }

    /**
     * Gets the currencydecimal char.
     *
     * @return the currencydecimal char
     */
    public String getCurrencydecimalChar() {
        return this.currencydecimalChar;
    }

    /**
     * Sets the currencydecimal char.
     *
     * @param currencydecimalChar
     *            the new currencydecimal char
     */
    public void setCurrencydecimalChar(String currencydecimalChar) {
        this.currencydecimalChar = currencydecimalChar;
    }

    /**
     * Gets the currencygrouping char html.
     *
     * @return the currencygrouping char html
     */
    public String getCurrencygroupingCharHtml() {
        return this.currencygroupingCharHtml;
    }

    /**
     * Sets the currencygrouping char html.
     *
     * @param currencygroupingCharHtml
     *            the new currencygrouping char html
     */
    public void setCurrencygroupingCharHtml(String currencygroupingCharHtml) {
        this.currencygroupingCharHtml = currencygroupingCharHtml;
    }

    /**
     * Gets the currencydecimal char html.
     *
     * @return the currencydecimal char html
     */
    public String getCurrencydecimalCharHtml() {
        return this.currencydecimalCharHtml;
    }

    /**
     * Sets the currencydecimal char html.
     *
     * @param currencydecimalCharHtml
     *            the new currencydecimal char html
     */
    public void setCurrencydecimalCharHtml(String currencydecimalCharHtml) {
        this.currencydecimalCharHtml = currencydecimalCharHtml;
    }

}
