package com.itx.feeds.templates.feedstemplateeditor.export;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.javatuples.Quartet;

import com.itx.feeds.templates.feedstemplateeditor.common.PartNumberUtils;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Attachment;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Category;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Composition;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.CompositionWrapper;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Image;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.MocaColor;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.MocaI18nCategory;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.MocaI18nColor;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.MocaI18nSize;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.MocaSize;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Price;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Size;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.StoreCatalogLanguageCategories;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.SupportedLanguage;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Tag;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.CategoriesList;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.Moca;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.MocaI18n;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.MocaStore;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.Store;




// TODO: Auto-generated Javadoc
/**
 * Utilities for export files generation.
 *
 */
public class ExportObjectsUtils {


    /**
     * @param moca
     */
    private static Boolean hasMocaXmediaImage(Moca moca) {
        if (moca.getData().getColor() != null && !moca.getData().getColor().isEmpty()) {
            for (MocaColor mocaColor : moca.getData().getColor()) {
                if (mocaColor.getImage() != null) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Gets the supported language by id.
     *
     * @param languageId
     *            the language id
     * @param store
     *            the store
     * @return Get the SupportedLanguage of a store/languageId introduced
     */
    public static SupportedLanguage getSupportedLanguageById(Integer languageId, Store store) {

        for (SupportedLanguage supportedLanguage : store.getData().getSupportedLanguage()) {
            if (supportedLanguage.getId() == languageId) {
                return supportedLanguage;
            }
        }
        return null;
    }

    /**
     * Gets the size by moca store.
     *
     * @param mocaStore
     *            the moca store
     * @param sku
     *            the sku
     * @return Get the Size, of the mocaStore and sku introduced.
     */
    public static Size getSizeByMocaStore(MocaStore mocaStore, Long sku) {
        for (Size size : mocaStore.getData().getSizes()) {
            if (size.getSku().equals(sku)) {
                return size;
            }
        }
        return new Size();
    }

    /**
     * Gets if there are stock on MocaStore
     *
     * @param mocaStore
     *            the moca store
     * @return Get if the mocaStore has stock for the product
     */
    public static Boolean haveStockProductInMocaStore(MocaStore mocaStore) {
        if (mocaStore.getData().getSizes() != null) {
            for (Size size : mocaStore.getData().getSizes()) {
                if (size.getHasStock()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Gets if there are stock on MocaStore
     *
     * @param mocaStore
     *            the moca store
     * @return Get if the mocaStore has stock for the product
     */
    public static Boolean haveStockOrComingBackSoonProductInMocaStore(MocaStore mocaStore) {
        if (mocaStore.getData().getSizes() != null) {
            for (Size size : mocaStore.getData().getSizes()) {
                if (size.getHasStock() || size.getBackSoon().equalsIgnoreCase("true")
                        || size.getComingSoon().equalsIgnoreCase("true")) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Gets if there are stock on MocaColor
     *
     * @param brandId
     * @param idColor
     * @param mocaSizes
     * @param mocaStore
     * @return Get if the mocaStore has stock for the product
     */
    public static Boolean hasStockMocaColor(Integer brandId, String idColor, List<MocaSize> mocaSizes,
            MocaStore mocaStore) {

        if (mocaSizes != null) {
            for (MocaSize mocaSize : mocaSizes) {
                if (PartNumberUtils.getColorCodeAsStringFromPartNumber(brandId, mocaSize.getPartNumber())
                        .equals(idColor)) {
                    Size size = getSizeByMocaStore(mocaStore, mocaSize.getSku());
                    if (size != null && size.getHasStock() != null && size.getHasStock()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Gets if there are stock on MocaColor
     *
     * @param brandId
     * @param idColor
     * @param mocaSizes
     * @param mocaStore
     * @return Get if the mocaStore has stock for the product
     */
    public static Boolean hasStockOrComingBackSoonMocaColor(Integer brandId, String idColor, List<MocaSize> mocaSizes,
            MocaStore mocaStore) {

        if (mocaSizes != null) {
            for (MocaSize mocaSize : mocaSizes) {
                if (PartNumberUtils.getColorCodeAsStringFromPartNumber(brandId, mocaSize.getPartNumber())
                        .equals(idColor)) {
                    Size size = getSizeByMocaStore(mocaStore, mocaSize.getSku());
                    if (size != null && ((size.getHasStock() != null && size.getHasStock())
                            || size.getBackSoon().equalsIgnoreCase("true")
                            || size.getComingSoon().equalsIgnoreCase("true"))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * @param languageId
     * @param storeId
     * @param catalogId
     * @param categoryId
     * @param categoriesMap
     * @return Category
     */
    public static Category getCategoryInCategoriesTreeMap(Integer languageId, Integer storeId, Integer catalogId,
            Long categoryId, SortedMap<Quartet<Integer, Integer, Integer, Long>, Category> categoriesMap) {

        Quartet<Integer, Integer, Integer, Long> languageStoreCategory = new Quartet<Integer, Integer, Integer, Long>(
                languageId, storeId, catalogId, categoryId);
        if (categoriesMap.containsKey(languageStoreCategory)) {
            return categoriesMap.get(languageStoreCategory);
        }

        return null;

    }

    /**
     * @param category
     * @return List Category
     */
    public static List<Category> getCategoriesToExportPath(Category category) {
        List<Category> categoriesList = new ArrayList<Category>();

        getCategoriesToExportPath(categoriesList, category);

        Collections.reverse(categoriesList);
        return categoriesList;
    }

    /**
     * @param categoriesList
     * @param category
     */
    private static void getCategoriesToExportPath(List<Category> categoriesList, Category category) {
        if (category != null) {
            categoriesList.add(category);
            getCategoriesToExportPath(categoriesList, category.getParent());
        }
    }

    /**
     * Gets the color by moca i18n.
     *
     * @param mocaI18n
     *            the moca i18n
     * @param idColor
     *            the id color
     * @return Return the locale name of the mocaI18n and idColor introduced.
     */
    public static String getColorByMocaI18n(MocaI18n mocaI18n, String idColor) {
        for (MocaI18nColor mocaI18nColor : mocaI18n.getData().getColor()) {
            if (mocaI18nColor.getIdColor().equals(idColor)) {
                if (mocaI18nColor.getName() != null) {
                    return mocaI18nColor.getName();
                } else {
                    return "";
                }
            }
        }
        return "";
    }

    /**
     * Gets the size by moca i18n.
     *
     * @param mocaI18n
     *            the moca i18n
     * @param sku
     *            the sku
     * @param sizeId
     * @return Get the locale name of the size of the mocaI18n and sku introduced.
     */
    public static String getSizeByMocaI18n(MocaI18n mocaI18n, Long sku, String sizeId) {
        for (MocaI18nSize mocaI18nSize : mocaI18n.getData().getSize()) {
            if (mocaI18nSize.getSku().equals(sku)) {
                return mocaI18nSize.getName().trim().isEmpty() ? sizeId : mocaI18nSize.getName().trim();
            }
        }
        return sizeId;
    }

    /**
     * Gets the material by moca i18n.
     *
     * @param mocaI18n
     *            the moca i18n
     * @param idColor
     *            the id color
     * @return Get the locale names of all materials of the mocaI18 and idColor introduced.
     */
    public static String getMaterialByMocaI18n(MocaI18n mocaI18n, String idColor) {
        List<String> material = new ArrayList<String>();

        if (mocaI18n.getData().getColor() != null && !mocaI18n.getData().getColor().isEmpty()) {
            for (MocaI18nColor mocaI18nColor : mocaI18n.getData().getColor()) {
                if ((mocaI18nColor.getIdColor().equals(idColor) || idColor.isEmpty())
                        && mocaI18nColor.getComposition() != null) {
                    for (CompositionWrapper compositionWrapper : mocaI18nColor.getComposition()) {
                        for (Composition composition : compositionWrapper.getComposition()) {
                            if (!material.contains(composition.getName())) {
                                material.add(composition.getName());
                            }
                        }
                    }
                }
            }

        }

        return getMaterialString(material);
    }

    /**
     * @param material
     * @return string for Lengow Material
     */
    private static String getMaterialString(List<String> material) {
        String materialString = "";

        for (String name : material) {
            materialString = materialString.concat(name) + ',';
        }
        return materialString;
    }

    /**
     * Gets the moca is new.
     *
     * @param mocaI18n
     *            the moca i18n
     * @return Return a yes/no string, if the mocaI18n is new or not.
     */
    public static String getMocaIsNew(MocaI18n mocaI18n) {

        if (mocaI18n.getData().getRelatedCategories() != null) {
            for (MocaI18nCategory mocaI18nCategory : mocaI18n.getData().getRelatedCategories()) {
                if (mocaI18nCategory.getIdentifier().contains("NEW")) {
                    return "yes";
                }
            }
        }
        return "no";
    }

    /**
     * Checks for stock.
     *
     * @param hasStock
     *            the has stock
     * @return Return a yes/no string, if hasStock is true or false.
     */
    public static String hasStock(Boolean hasStock) {
        if (hasStock) {
            return "yes";
        }
        return "no";
    }

    /**
     * Gets the ean item.
     *
     * @param partnumber
     *            the partnumber
     * @return Return the ean of the introduced partnumber.
     */
    public static String getEANItem(String partnumber) {
        Integer pv = new Integer(0);
        Integer p1 = Integer.parseInt(partnumber.substring(1, 2));
        Integer p2 = Integer.parseInt(partnumber.substring(2, 3));
        Integer p3 = Integer.parseInt(partnumber.substring(3, 4));
        Integer p4 = Integer.parseInt(partnumber.substring(4, 5));
        Integer p5 = Integer.parseInt(partnumber.substring(5, 6));
        Integer p6 = Integer.parseInt(partnumber.substring(6, 7));
        Integer p7 = Integer.parseInt(partnumber.substring(7, 8));

        Integer n6 = (pv + p2 + p4 + p6) * 3 + p1 + p3 + p5 + p7;
        Integer aux = n6 / 10;
        Integer o6 = (aux + 1) * 10000;

        Integer ean = o6 - n6;
        StringBuilder result = new StringBuilder();

        result = result.append(pv).append(p1).append(p2).append(p3).append(p4).append(p5).append(p6).append(p7)
                .append(ean);

        String eanCode = result.toString();
        if (eanCode.length() > 13 && !(eanCode.indexOf('0', 0) == 0)) {
            // LOG.info(METHOD, String.format("pv: %s | p1: %s | p2: %s | p3: %s | p4: %s | p5: %s | p6: %s | p7: %s ",
            // pv, p1, p2, p3, p4, p5, p6, p7));
            // LOG.info(METHOD, String.format("n6: %s", n6));
            // LOG.info(METHOD, String.format("o6: %s", o6));


        }
        return eanCode;
    }

    /**
     * @param moca
     * @param idColor
     * @return Image
     */
    public static Image getImageByMocaIdColor(Moca moca, String idColor) {
        if (moca.getData().getColor() != null) {
            for (MocaColor mocaColor : moca.getData().getColor()) {
                if (mocaColor.getIdColor().equals(idColor)) {
                    return mocaColor.getImage();
                }
            }
        }
        return null;

    }

    /**
     * @param storeId
     * @param storesMap
     * @return StoreID
     */
    public static Store getStoreByStoreIdStoreMap(Integer storeId, Map<Integer, Store> storesMap) {
        if (storesMap.containsKey(storeId)) {
            return storesMap.get(storeId);
        }
        return null;
    }

    /**
     * @param moca
     * @param idColor
     * @return List MocaSize
     */
    public static List<MocaSize> getMocaSizesByIdColor(Moca moca, String idColor) {
        List<MocaSize> mocaSizes = new ArrayList<MocaSize>();

        if (moca.getData().getSizes() != null) {
            for (MocaSize mocaSize : moca.getData().getSizes()) {
                if (PartNumberUtils.getColorCodeAsStringFromPartNumber(moca.getBrandId(), mocaSize.getPartNumber())
                        .equals(idColor)) {
                    mocaSizes.add(mocaSize);
                }
            }
        }
        return mocaSizes;
    }

    /**
     * @param mocaI18n
     * @param sku
     * @return MocaI18nSize
     */
    public static MocaI18nSize getMocaI18nSizeBySku(MocaI18n mocaI18n, Long sku) {
        for (MocaI18nSize mocaI18nSize : mocaI18n.getData().getSize()) {
            if (mocaI18nSize.getSku().equals(sku)) {
                return mocaI18nSize;
            }
        }
        return null;
    }

    /**
     * Gets the category name.
     *
     * @param idCategory
     *            the id category
     * @param mocaI18n
     *            the moca i18n
     * @return Get the name of a category
     */
    public static String getCategoryName(Long idCategory, MocaI18n mocaI18n) {

        for (MocaI18nCategory mocaI18nCategory : mocaI18n.getData().getRelatedCategories()) {
            if (mocaI18nCategory.getId().equals(idCategory)) {
                return mocaI18nCategory.getName();
            }
        }
        return "";
    }

    /**
     * Gets the map categories tree.
     *
     * @param categoriesList
     *            the categories list
     * @return Get Map with the categories Tree
     */
    public static SortedMap<Long, Long> getMapCategoriesTree(List<CategoriesList> categoriesList) {
        SortedMap<Long, Long> mapCategoriesTree = new TreeMap<Long, Long>();

        for (CategoriesList categoryList : categoriesList) {
            for (StoreCatalogLanguageCategories storeCategory : categoryList.getData()
                    .getStoreCatalogLanguageCategories()) {
                for (Category category : storeCategory.getCategories()) {
                    mapCategoriesTree.put(category.getIdCategory(), null);

                    if (category.getSubcategories() != null) {
                        mapCategoriesTree.putAll(ExportObjectsUtils.getMapCategoriesTree(mapCategoriesTree,
                                category.getSubcategories(), category.getIdCategory()));

                    }
                }
            }
        }
        return mapCategoriesTree;
    }

    /**
     * Gets the map categories tree.
     *
     * @param mapCategoriesTree
     *            the map categories tree
     * @param subcategories
     *            the subcategories
     * @param categoryParentId
     *            the category parent id
     * @return The map with category parentId and category childId
     */
    public static SortedMap<Long, Long> getMapCategoriesTree(SortedMap<Long, Long> mapCategoriesTree,
            List<Category> subcategories, Long categoryParentId) {

        for (Category category : subcategories) {
            mapCategoriesTree.put(category.getIdCategory(), categoryParentId);

            if (category.getSubcategories() != null) {
                mapCategoriesTree.putAll(
                        getMapCategoriesTree(mapCategoriesTree, category.getSubcategories(), category.getIdCategory()));

            }
        }

        return mapCategoriesTree;
    }

    /**
     * @param priceList
     * @return Price
     */
    public static Price getFuturePrice(List<Price> priceList, Boolean isVIP, boolean onlyPromoIds) {
        Price futurePrice = null;
        Calendar fecha = new GregorianCalendar();

        if (priceList != null) {
            for (Price price : priceList) {
                if (price.getIsVIP().equals(isVIP)
                        && (!onlyPromoIds || onlyPromoIds && price.getPromotionId() != null)) {
                    if (price.getStartDate() != null && price.getStartDate().compareTo(fecha.getTime()) > 0) {
                        if (futurePrice == null) {
                            futurePrice = price;
                        } else {
                            if (futurePrice.getPrecedence() < price.getPrecedence()
                                    || (futurePrice.getPrecedence().equals(price.getPrecedence())
                                            && futurePrice.getLastUpdateDate().before(price.getLastUpdateDate()))) {
                                futurePrice = price;
                            }
                        }
                    }
                }
            }
        }
        return futurePrice;
    }

    /**
     * @param priceList
     * @return Price
     */
    public static Price getFuturePrice(List<Price> priceList) {
        // POr defect solo cogeremos registros noVIP y que tengan ids de promocion
        return getFuturePrice(priceList, false, true);
    }

    /**
     * @param priceList
     * @return Price
     */
    public static Price getCurrentPrice(List<Price> priceList, Boolean isVIP) {
        Price currentPrice = null;
        Calendar fecha = new GregorianCalendar();

        if (priceList != null) {
            for (Price price : priceList) {
                if (price.getIsVIP().equals(isVIP)) {
                    if ((price.getStartDate() == null || price.getStartDate().compareTo(fecha.getTime()) <= 0)
                            && (price.getEndDate() == null || price.getEndDate().compareTo(fecha.getTime()) >= 0)) {
                        if (currentPrice == null) {
                            currentPrice = price;
                        } else {
                            if (currentPrice.getPrecedence() < price.getPrecedence()
                                    || (currentPrice.getPrecedence().equals(price.getPrecedence())
                                            && currentPrice.getLastUpdateDate().before(price.getLastUpdateDate()))) {
                                currentPrice = price;
                            }
                        }
                    }
                }
            }
        }
        return currentPrice;
    }

    /**
     * @param priceList
     * @return Price
     */
    public static Price getCurrentPrice(List<Price> priceList) {

        return getCurrentPrice(priceList, false);
    }

    /**
     * Gets the attachments by moca i18n.
     *
     * @param mocaI18n
     *            the moca i18n
     * @return the attachments by moca i18n
     */
    public static List<Attachment> getAttachmentsByMocaI18n(MocaI18n mocaI18n) {
        List<Attachment> attachments = new ArrayList<Attachment>();
        if (mocaI18n.getData().getTags() != null) {
            for (Tag tag : mocaI18n.getData().getTags()) {
                attachments.addAll(tag.getAttachments());
            }
        }

        return attachments;
    }

    /**
     * @param identifier
     * @param mocaI18n
     * @return String
     */
    public static String getCategoryNameByIdentifierMocaI18n(String identifier, MocaI18n mocaI18n) {

        if (mocaI18n.getData().getTags() != null) {
            for (Tag tag : mocaI18n.getData().getTags()) {
                if (tag.getCategory().getIdentifier().equals(identifier)) {
                    return tag.getCategory().getName();
                }
            }
        }

        return null;
    }

    /**
     * @param id
     * @param mocaI18n
     * @return String
     */
    public static String getCategoryNameByIdMocaI18n(Long id, MocaI18n mocaI18n) {

        if (mocaI18n.getData().getRelatedCategories() != null) {
            for (MocaI18nCategory mocaI18nCategory : mocaI18n.getData().getRelatedCategories()) {
                if (mocaI18nCategory.getId().equals(id)) {
                    return mocaI18nCategory.getName();
                }
            }
        }

        return "";
    }

    /**
     * @param mocaI18ns
     * @return String
     */
    public static List<MocaI18nCategory> getRelatedCategoriesByMocaI18nsLanguage(List<MocaI18n> mocaI18ns) {
        Map<Long, MocaI18nCategory> relatedCategories = new HashMap<Long, MocaI18nCategory>();

        for (MocaI18n mocaI18n : mocaI18ns) {
            for (MocaI18nCategory mocaI18nCategory : mocaI18n.getData().getRelatedCategories()) {
                if (!relatedCategories.containsKey(mocaI18nCategory.getId())) {
                    relatedCategories.put(mocaI18nCategory.getId(), mocaI18nCategory);
                }
            }
        }
        return new ArrayList<MocaI18nCategory>(relatedCategories.values());
    }

    /**
     * @param price
     * @return price formated
     */
    public static String getPriceByFormatCurrency(String price) {
        if (price != null) {
            return String.format(Locale.ROOT, "%.2f", Double.valueOf(price)).trim();
        } else {
            return "";
        }
    }

    /**
     * @param price
     * @param format
     * @return String
     */
    public static String getPriceByFormatCurrency(String price, String format) {
        if (price != null) {
            if (format != null && !format.isEmpty()) {
                return String.format(Locale.ROOT, format, Double.valueOf(price)).trim();
            } else {
                return getPriceByFormatCurrency(price);
            }
        } else {
            return "";
        }
    }

    // LENGOW
    /**
     * @param mocaI18n
     * @return String
     */
    public static String getSectionName(MocaI18n mocaI18n) {
        if (mocaI18n.getData().getSectionName() != null && !mocaI18n.getData().getSectionName().isEmpty()) {
            return mocaI18n.getData().getSectionName();
        } else {
            return mocaI18n.getData().getSection() != null ? mocaI18n.getData().getSection() : "";
        }
    }

    /**
     * @param mocaI18n
     * @return string
     */
    public static String getFamilyName(MocaI18n mocaI18n) {
        if (mocaI18n.getData().getFamilyName() != null && !mocaI18n.getData().getFamilyName().isEmpty()) {
            return mocaI18n.getData().getFamilyName();
        } else {
            return mocaI18n.getData().getFamily() != null ? mocaI18n.getData().getFamily() : "";
        }
    }

    /**
     * @param mocaI18n
     * @return string
     */
    public static String getSubfamilyName(MocaI18n mocaI18n) {
        if (mocaI18n.getData().getSubfamilyName() != null && !mocaI18n.getData().getSubfamilyName().isEmpty()) {
            return mocaI18n.getData().getSubfamilyName();
        } else {
            return mocaI18n.getData().getSubfamily() != null ? mocaI18n.getData().getSubfamily() : "";
        }
    }

    /**
     *
     * @param urlToDecode
     * @param encoding
     * @return string with part of url decoded
     */
    public static String decodeURL(String urlToDecode, String encoding) {
        try {
            return URLDecoder.decode(urlToDecode, encoding);
        } catch (UnsupportedEncodingException e) {
        	e.printStackTrace();
        }
        return urlToDecode;
    }

}
