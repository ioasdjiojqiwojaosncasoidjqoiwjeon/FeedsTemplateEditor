package com.itx.feeds.templates.feedstemplateeditor;

import java.io.StringWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import com.itx.feeds.templates.feedstemplateeditor.common.Constants;
import com.itx.feeds.templates.feedstemplateeditor.common.PartNumberUtils;
import com.itx.feeds.templates.feedstemplateeditor.export.ConfigurationUtils;
import com.itx.feeds.templates.feedstemplateeditor.export.ExportObjectsUtils;
import com.itx.feeds.templates.feedstemplateeditor.export.TemplateConfig;
import com.itx.feeds.templates.feedstemplateeditor.model.ExportableModel;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.wrapper.ExportConfiguration;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl.TemplateContent;

import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapper;
import freemarker.template.TemplateHashModel;

public class TemplateModelParser {

	public String parseExportableModelWithTemplateByStrategy(ExportableModel exportableModel,
			ExportConfiguration exportConfiguration, Map<String, TemplateContent> editedTemplateContentMap) {
		try {
			// We load Freemarker context with the new contents of the template
			Map<Integer, TemplateConfig> template = ConfigurationUtils.loadTemplateMap(
					exportConfiguration.getTemplatesConfiguration(),
					editedTemplateContentMap.values().stream().collect(Collectors.toList()));

			DefaultObjectWrapper wrapper = new DefaultObjectWrapper(Configuration.VERSION_2_3_28);
			TemplateHashModel staticsMethods = wrapper.getStaticModels();
			TemplateHashModel partnumberUtils;
			partnumberUtils = (TemplateHashModel) staticsMethods.get(PartNumberUtils.class.getName());

			TemplateHashModel configurationUtils = (TemplateHashModel) staticsMethods
					.get(ConfigurationUtils.class.getName());

			TemplateHashModel exportObjectUtils = (TemplateHashModel) staticsMethods
					.get(ExportObjectsUtils.class.getName());

			TemplateHashModel constants = (TemplateHashModel) staticsMethods.get(Constants.class.getName());

			Map<String, Object> export = new HashMap<String, Object>();

			// COMMON MODELS
			export.put("constants", constants);
			export.put("exportObjectUtils", exportObjectUtils);
			export.put("partnumberUtils", partnumberUtils);
			export.put("configurationUtils", configurationUtils);
			export.put("configMap", exportableModel.getConfigurationMap());
			export.put("categoriesMap", exportableModel.getCategoriesMap());
			export.put("brand", exportableModel.getBrand());
			export.put("moca", exportableModel.getMoca());

			// Load models depends on parser strategy that we have configured
			switch (exportConfiguration.getExportFileTypeConfiguration().getData().getFileGenerationStrategy()) {
			case "": // PRODUCER BY BRAND
				export.put("storesMap", exportableModel.getStoresMap());
				break;
			case "LANGUAGE": // PRODUCER BY LANGUAGE
				export.put("mocaI18ns", exportableModel.getMocaI18ns());
				export.put("mocaStores", exportableModel.getMocaStores());
				export.put("storesMap", exportableModel.getStoresMap());
				export.put("bundleProducts", "Al final esto es la inyección de parseo del "
						+ "mismo template pero con los bundles, no disponible el resultado en este tester");
				break;
			case "STORE": // PRODUCER BY LANGUAGE
				export.put("storeExportLanguages", Arrays.asList(exportableModel.getLanguage().getId()));
			case "STORE#LANGUAGE": // PRODUCER BY STORE#LANGUAGE
				export.put("store", exportableModel.getStore());
				export.put("language", exportableModel.getLanguage());
				export.put("mocaStore", exportableModel.getMocaStore());
				export.put("mocaI18n", exportableModel.getMocaI18n());
			}

			StringWriter stringWriter = new StringWriter();
			template.get(null).getTemplate().process(export, stringWriter);

			return stringWriter.toString();

		} catch (Exception e) {
			return e.getMessage();

		}
	}

}
