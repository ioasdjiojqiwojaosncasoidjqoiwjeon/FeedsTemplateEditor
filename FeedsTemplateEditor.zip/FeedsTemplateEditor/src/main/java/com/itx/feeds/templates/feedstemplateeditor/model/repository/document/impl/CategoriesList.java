package com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl.CategoriesListData;

// TODO: Auto-generated Javadoc
/**
 * The Class CategoriesList.
 */
public class CategoriesList extends AbstractBrandedVersionedDocumentImpl<CategoriesListData> {

    /** The store id. */
    private Integer storeId;

    /** The catalog id. */
    private Integer catalogId;

    /** The language id. */
    private Integer languageId;

    /**
     * Instantiates a new categories list.
     *
     * @param data
     *            the data
     * @param feedsVersion
     *            the feeds version
     * @param brandId
     *            the brand id
     * @param storeId
     *            the store id
     * @param catalogId
     *            the catalog id
     */
    public CategoriesList(CategoriesListData data, long feedsVersion, Integer brandId, Integer storeId,
            Integer catalogId) {
        super(data, feedsVersion, brandId);
        this.storeId = storeId;
        this.catalogId = catalogId;
    }

    /**
     * Instantiates a new categories list.
     */
    public CategoriesList() {
        super();
    }

    /**
     * Gets the store id.
     *
     * @return the store id
     */
    public Integer getStoreId() {
        return this.storeId;
    }

    /**
     * Sets the store id.
     *
     * @param storeId
     *            the new store id
     */
    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    /**
     * Gets the catalog Id.
     *
     * @return the catalog id
     */
    public Integer getCatalogId() {
        return this.catalogId;
    }

    /**
     * Sets the catalog id.
     *
     * @param catalogId
     *            the new catalog Id
     */
    public void setCatalogId(Integer catalogId) {
        this.catalogId = catalogId;
    }

    /**
     * @return the languageId
     */
    public Integer getLanguageId() {
        return languageId;
    }

    /**
     * @param languageId
     *            the languageId to set
     */
    public void setLanguageId(Integer languageId) {
        this.languageId = languageId;
    }

}
