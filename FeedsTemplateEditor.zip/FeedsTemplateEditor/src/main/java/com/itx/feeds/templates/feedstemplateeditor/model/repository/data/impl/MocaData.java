package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl;

import java.util.List;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Attribute;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.MocaColor;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.MocaSize;
import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner.Xmedia;

// TODO: Auto-generated Javadoc
/**
 * The Class MocaData.
 */
public class MocaData extends AbstractDocumentDataImpl {

    /** The nameEN. */
    private String nameEN;

    /** The section. */
    private String section;

    /** The sectionNameEN. */
    private String sectionNameEN;

    /** The familyMaster. */
    private String familyMaster;

    /** The family. */
    private String family;

    /** The familyNameEN. */
    private String familyNameEN;

    /** The subfamilyMaster. */
    private String subfamilyMaster;

    /** The subfamily. */
    private String subfamily;

    /** The subFamilyNameEN lot. */
    private String subFamilyNameEN;

    /** The units lot. */
    private Integer unitsLot;

    /** The is top. */
    private Integer isTop;

    /** The gridElementType. */
    private String gridElementType;

    /** The type. */
    private String type;

    /** The on special. */
    private Boolean onSpecial;

    /** The product type. */
    private String productType;

    /** The field5. */
    private String field5;

    /** The main color id. */
    private String mainColorId;

    /** The size system. */
    private String sizeSystem;

    /** The is sales. */
    private Boolean isSales;

    /** The reference. */
    private String reference;

    /** The display reference. */
    private String displayReference;

    /** The start date. */
    private String startDate;

    /** The product url param. */
    private String productUrlParam;

    /** The availability date. */
    private String availabilityDate;

    /** The backsoon. */
    private String backSoon;

    /** The attributes. */
    private List<Attribute> attributes;

    /** The xmedia. */
    private List<Xmedia> xmedia;

    /** The color. */
    private List<MocaColor> color;

    /** The sizes. */
    private List<MocaSize> sizes;

    private Boolean isJoinLife;

    /**
     * Instantiates a new moca data.
     *
     * @param unitsLot
     * @param isTop
     * @param gridElementType
     * @param type
     * @param onSpecial
     * @param productType
     * @param section
     * @param field5
     * @param mainColorId
     * @param sizeSystem
     * @param isSales
     * @param reference
     * @param displayReference
     * @param startDate
     * @param attributes
     * @param xmedia
     * @param color
     * @param sizes
     */
    public MocaData(String nameEN, String section, String sectionNameEN, String familyMaster, String family,
            String familyNameEN, String subfamilyMaster, String subfamily, String subFamilyNameEN, Integer unitsLot,
            Integer isTop, String type, Boolean onSpecial, String productType, String field5, String mainColorId,
            String sizeSystem, Boolean isSales, String reference, String displayReference, String startDate,
            List<Attribute> attributes, List<Xmedia> xmedia, List<MocaColor> color, List<MocaSize> sizes,
            String availabilityDate, String productUrlParam, String gridElementType, String backSoon,
            Boolean isJoinLife) {
        super();
        this.nameEN = nameEN;
        this.section = section;
        this.sectionNameEN = sectionNameEN;
        this.familyMaster = familyMaster;
        this.family = family;
        this.familyNameEN = familyNameEN;
        this.subfamilyMaster = subfamilyMaster;
        this.subfamily = subfamily;
        this.subFamilyNameEN = subFamilyNameEN;
        this.unitsLot = unitsLot;
        this.isTop = isTop;
        this.type = type;
        this.onSpecial = onSpecial;
        this.availabilityDate = availabilityDate;
        this.productType = productType;
        this.field5 = field5;
        this.mainColorId = mainColorId;
        this.sizeSystem = sizeSystem;
        this.isSales = isSales;
        this.reference = reference;
        this.displayReference = displayReference;
        this.startDate = startDate;
        this.attributes = attributes;
        this.xmedia = xmedia;
        this.color = color;
        this.sizes = sizes;
        this.productUrlParam = productUrlParam;
        this.gridElementType = gridElementType;
        this.backSoon = backSoon;
        this.isJoinLife = isJoinLife;
    }

    /**
     * Instantiates a new moca data.
     */
    public MocaData() {
        super();
    }

    /**
     * @return the nameEN
     */
    public String getNameEN() {
        return nameEN;
    }

    /**
     * @param nameEN
     *            the nameEN to set
     */
    public void setNameEN(String nameEN) {
        this.nameEN = nameEN;
    }

    /**
     * @return the sectionNameEN
     */
    public String getSectionNameEN() {
        return sectionNameEN;
    }

    /**
     * @return the familyMaster
     */
    public String getFamilyMaster() {
        return familyMaster;
    }

    /**
     * @param familyMaster
     *            the familyMaster to set
     */
    public void setFamilyMaster(String familyMaster) {
        this.familyMaster = familyMaster;
    }

    /**
     * @return the family
     */
    public String getFamily() {
        return family;
    }

    /**
     * @return the familyNameEN
     */
    public String getFamilyNameEN() {
        return familyNameEN;
    }

    /**
     * @return the subfamilyMaster
     */
    public String getSubfamilyMaster() {
        return subfamilyMaster;
    }

    /**
     * @param subfamilyMaster
     *            the subfamilyMaster to set
     */
    public void setSubfamilyMaster(String subfamilyMaster) {
        this.subfamilyMaster = subfamilyMaster;
    }

    /**
     * @return the subfamily
     */
    public String getSubfamily() {
        return subfamily;
    }

    /**
     * @return the subFamilyNameEN
     */
    public String getSubFamilyNameEN() {
        return subFamilyNameEN;
    }

    /**
     * @param sectionNameEN
     *            the sectionNameEN to set
     */
    public void setSectionNameEN(String sectionNameEN) {
        this.sectionNameEN = sectionNameEN;
    }

    /**
     * @param family
     *            the family to set
     */
    public void setFamily(String family) {
        this.family = family;
    }

    /**
     * @param familyNameEN
     *            the familyNameEN to set
     */
    public void setFamilyNameEN(String familyNameEN) {
        this.familyNameEN = familyNameEN;
    }

    /**
     * @param subfamily
     *            the subfamily to set
     */
    public void setSubfamily(String subfamily) {
        this.subfamily = subfamily;
    }

    /**
     * @param subFamilyNameEN
     *            the subFamilyNameEN to set
     */
    public void setSubFamilyNameEN(String subFamilyNameEN) {
        this.subFamilyNameEN = subFamilyNameEN;
    }

    /**
     * Gets the units lot.
     *
     * @return the units lot
     */
    public Integer getUnitsLot() {
        return this.unitsLot;
    }

    /**
     * Sets the units lot.
     *
     * @param unitsLot
     *            the new units lot
     */
    public void setUnitsLot(Integer unitsLot) {
        this.unitsLot = unitsLot;
    }

    /**
     * Gets the checks if is top.
     *
     * @return the checks if is top
     */
    public Integer getIsTop() {
        return this.isTop;
    }

    /**
     * Sets the checks if is top.
     *
     * @param isTop
     *            the new checks if is top
     */
    public void setIsTop(Integer isTop) {
        this.isTop = isTop;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return this.type;
    }

    /**
     * Sets the type.
     *
     * @param type
     *            the new type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Gets the on special.
     *
     * @return the on special
     */
    public Boolean getOnSpecial() {
        return this.onSpecial;
    }

    /**
     * Sets the on special.
     *
     * @param onSpecial
     *            the new on special
     */
    public void setOnSpecial(Boolean onSpecial) {
        this.onSpecial = onSpecial;
    }

    /**
     * Gets the product type.
     *
     * @return the product type
     */
    public String getProductType() {
        return this.productType;
    }

    /**
     * Sets the product type.
     *
     * @param productType
     *            the new product type
     */
    public void setProductType(String productType) {
        this.productType = productType;
    }

    /**
     * Gets the section.
     *
     * @return the section
     */
    public String getSection() {
        return this.section;
    }

    /**
     * Sets the section.
     *
     * @param section
     *            the new section
     */
    public void setSection(String section) {
        this.section = section;
    }

    /**
     * Gets the field5.
     *
     * @return the field5
     */
    public String getField5() {
        return this.field5;
    }

    /**
     * Sets the field5.
     *
     * @param field5
     *            the new field5
     */
    public void setField5(String field5) {
        this.field5 = field5;
    }

    /**
     * Gets the main color id.
     *
     * @return the main color id
     */
    public String getMainColorId() {
        return this.mainColorId;
    }

    /**
     * Sets the main color id.
     *
     * @param mainColorId
     *            the new main color id
     */
    public void setMainColorId(String mainColorId) {
        this.mainColorId = mainColorId;
    }

    /**
     * Gets the size system.
     *
     * @return the size system
     */
    public String getSizeSystem() {
        return this.sizeSystem;
    }

    /**
     * Sets the size system.
     *
     * @param sizeSystem
     *            the new size system
     */
    public void setSizeSystem(String sizeSystem) {
        this.sizeSystem = sizeSystem;
    }

    /**
     * Gets the checks if is sales.
     *
     * @return the checks if is sales
     */
    public Boolean getIsSales() {
        return this.isSales;
    }

    /**
     * Sets the checks if is sales.
     *
     * @param isSales
     *            the new checks if is sales
     */
    public void setIsSales(Boolean isSales) {
        this.isSales = isSales;
    }

    /**
     * Gets the reference.
     *
     * @return the reference
     */
    public String getReference() {
        return this.reference;
    }

    /**
     * Sets the reference.
     *
     * @param reference
     *            the new reference
     */
    public void setReference(String reference) {
        this.reference = reference;
    }

    /**
     * Gets the display reference.
     *
     * @return the display reference
     */
    public String getDisplayReference() {
        return this.displayReference;
    }

    /**
     * Sets the display reference.
     *
     * @param displayReference
     *            the new display reference
     */
    public void setDisplayReference(String displayReference) {
        this.displayReference = displayReference;
    }

    /**
     * Gets the start date.
     *
     * @return the start date
     */
    public String getStartDate() {
        return this.startDate;
    }

    /**
     * Sets the start date.
     *
     * @param startDate
     *            the new start date
     */
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    /**
     * Gets the product url param.
     *
     * @return the product url param
     */
    public String getProductUrlParam() {
        return productUrlParam;
    }

    /**
     * Sets the product url param.
     *
     * @param productUrlParam
     *            the new product url param
     */
    public void setProductUrlParam(String productUrlParam) {
        this.productUrlParam = productUrlParam;
    }

    /**
     * Gets the availability date.
     *
     * @return the availability date
     */
    public String getAvailabilityDate() {
        return this.availabilityDate;
    }

    /**
     * Sets the availability date.
     *
     * @param availabilityDate
     *            the new availability date
     */
    public void setAvailabilityDate(String availabilityDate) {
        this.availabilityDate = availabilityDate;
    }

    /**
     * Gets the attributes.
     *
     * @return the attributes
     */
    public List<Attribute> getAttributes() {
        return this.attributes;
    }

    /**
     * Sets the attributes.
     *
     * @param attributes
     *            the new attributes
     */
    public void setAttributes(List<Attribute> attributes) {
        this.attributes = attributes;
    }

    /**
     * Gets the xmedia.
     *
     * @return the xmedia
     */
    public List<Xmedia> getXmedia() {
        return this.xmedia;
    }

    /**
     * Sets the xmedia.
     *
     * @param xmedia
     *            the new xmedia
     */
    public void setXmedia(List<Xmedia> xmedia) {
        this.xmedia = xmedia;
    }

    /**
     * Gets the color.
     *
     * @return the color
     */
    public List<MocaColor> getColor() {
        return this.color;
    }

    /**
     * Sets the color.
     *
     * @param color
     *            the new color
     */
    public void setColor(List<MocaColor> color) {
        this.color = color;
    }

    /**
     * Gets the sizes.
     *
     * @return the sizes
     */
    public List<MocaSize> getSizes() {
        return this.sizes;
    }

    /**
     * Sets the sizes.
     *
     * @param sizes
     *            the new sizes
     */
    public void setSizes(List<MocaSize> sizes) {
        this.sizes = sizes;
    }

    /**
     * @return string
     */
    public String getGridElementType() {
        return gridElementType;
    }

    /**
     * @param gridElementType
     */
    public void setGridElementType(String gridElementType) {
        this.gridElementType = gridElementType;
    }

    /**
     * @return string
     */
    public String getBackSoon() {
        return backSoon;
    }

    /**
     * @param backSoon
     */
    public void setBackSoon(String backSoon) {
        this.backSoon = backSoon;
    }

    /**
     * @return the isJoinLife
     */
    public Boolean getIsJoinLife() {
        return isJoinLife;
    }

    /**
     * @param isJoinLife
     *            the isJoinLife to set
     */
    public void setIsJoinLife(Boolean isJoinLife) {
        this.isJoinLife = isJoinLife;
    }

}
