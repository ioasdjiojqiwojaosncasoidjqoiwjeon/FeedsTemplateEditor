package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.Map;

// TODO: Auto-generated Javadoc
/**
 * The Class MocaSize.
 */
public class MocaSize {

    /** The sku. */
    private Long sku;

    /** The part number. */
    private String partNumber;

    /** The master size id. */
    private String masterSizeId;

    /** The master size Type. */
    private String sizeType;

    private String gtinCode;

    private Map<String, String> skuDimension;

    /**
     * Instantiates a new moca size.
     *
     * @param sku
     *            the sku
     * @param partNumber
     *            the part number
     * @param masterSizeId
     *            the master size id
     * @param sizeType
     *            the size type
     */
    public MocaSize(Long sku, String partNumber, String masterSizeId, String sizeType, String gtinCode,
            Map<String, String> skuDimension) {
        super();
        this.sku = sku;
        this.partNumber = partNumber;
        this.masterSizeId = masterSizeId;
        this.sizeType = sizeType;
        this.skuDimension = skuDimension;
    }

    /**
     * Instantiates a new moca size.
     */
    public MocaSize() {
        super();
    }

    /**
     * Gets the sku.
     *
     * @return the sku
     */
    public Long getSku() {
        return this.sku;
    }

    /**
     * Sets the sku.
     *
     * @param sku
     *            the new sku
     */
    public void setSku(Long sku) {
        this.sku = sku;
    }

    /**
     * Gets the part number.
     *
     * @return the part number
     */
    public String getPartNumber() {
        return this.partNumber;
    }

    /**
     * Sets the part number.
     *
     * @param partNumber
     *            the new part number
     */
    public void setPartNumber(String partNumber) {
        this.partNumber = partNumber;
    }

    /**
     * Gets the master size id.
     *
     * @return the master size id
     */
    public String getMasterSizeId() {
        return this.masterSizeId;
    }

    /**
     * Sets the master size id.
     *
     * @param masterSizeId
     *            the new master size id
     */
    public void setMasterSizeId(String masterSizeId) {
        this.masterSizeId = masterSizeId;
    }

    /**
     * Gets the size type.
     *
     * @return the size type
     */
    public String getSizeType() {
        return this.sizeType;
    }

    /**
     * Sets the size type.
     *
     * @param sizeType
     *            the new size type
     */
    public void setSizeType(String sizeType) {
        this.sizeType = sizeType;
    }

    /**
     * @return the gtinCode
     */
    public String getGtinCode() {
        return gtinCode;
    }

    /**
     * @param gtinCode
     *            the gtinCode to set
     */
    public void setGtinCode(String gtinCode) {
        this.gtinCode = gtinCode;
    }

    /**
     * @return the skuDimension
     */
    public Map<String, String> getSkuDimension() {
        return skuDimension;
    }

    /**
     * @param skuDimension
     *            the skuDimension to set
     */
    public void setSkuDimension(Map<String, String> skuDimension) {
        this.skuDimension = skuDimension;
    }

}
