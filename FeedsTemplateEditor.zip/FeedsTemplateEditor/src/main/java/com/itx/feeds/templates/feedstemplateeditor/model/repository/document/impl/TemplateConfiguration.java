package com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl.TemplateConfigurationData;

// TODO: Auto-generated Javadoc
/**
 * The Template Configuration.
 */
public class TemplateConfiguration extends AbstractDocumentImpl<TemplateConfigurationData> {

    /** The exportFileType. */
    private String exportFileType;

    /** The brand id. */
    private Integer brandId;

    /** The store id. */
    private Integer storeId;

    /**
     * Instantiates a new configuration.
     *
     * @param data
     *            the data
     * @param exportFileType
     *            the exportFileType
     * @param brandId
     *            the brand id
     * @param storeId
     *            the store id
     */
    public TemplateConfiguration(TemplateConfigurationData data, String exportFileType, Integer brandId,
            Integer storeId) {
        this.exportFileType = exportFileType;
        this.brandId = brandId;
        this.storeId = storeId;
    }

    /**
     * Instantiates a new Template configuration.
     */
    public TemplateConfiguration() {
        super();
    }

    /**
     * Gets the exportFileType.
     *
     * @return the exportFileType
     */
    public String getExportFileType() {
        return this.exportFileType;
    }

    /**
     * Sets the exportFileType.
     *
     * @param exportFileType
     *            the exportFileType
     */
    public void setExportFileType(String exportFileType) {
        this.exportFileType = exportFileType;
    }

    /**
     * Gets the brand id.
     *
     * @return the brand id
     */
    public Integer getBrandId() {
        return this.brandId;
    }

    /**
     * Sets the brand id.
     *
     * @param brandId
     *            the new brand id
     */
    public void setBrandId(Integer brandId) {
        this.brandId = brandId;
    }

    /**
     * Gets the store id.
     *
     * @return the store id
     */
    public Integer getStoreId() {
        return this.storeId;
    }

    /**
     * Sets the store id.
     *
     * @param storeId
     *            the new store id
     */
    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

}
