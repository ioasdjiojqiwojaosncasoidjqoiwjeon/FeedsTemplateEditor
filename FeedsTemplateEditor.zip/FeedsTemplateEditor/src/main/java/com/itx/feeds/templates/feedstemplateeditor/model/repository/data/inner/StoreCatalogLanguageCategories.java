package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

/**
 * @author luisvpi
 *
 */
public class StoreCatalogLanguageCategories {

    /** The app id. */
    private Integer appId;

    /** The categories. */
    private List<Category> categories;

    /**
     * @param appId
     * @param categories
     */
    public StoreCatalogLanguageCategories(Integer appId, List<Category> categories) {
        super();
        this.appId = appId;
        this.categories = categories;
    }

    /**
     * StoreCatalogLanguageCategories
     */
    public StoreCatalogLanguageCategories() {
        super();
    }

    /**
     * Gets the app id.
     *
     * @return the app id
     */
    public Integer getAppId() {
        return this.appId;
    }

    /**
     * Sets the app id.
     *
     * @param appId
     *            the new app id
     */
    public void setAppId(Integer appId) {
        this.appId = appId;
    }

    /**
     * Gets the categories.
     *
     * @return the categories
     */
    public List<Category> getCategories() {
        return this.categories;
    }

    /**
     * Sets the categories.
     *
     * @param categories
     *            the new categories
     */
    public void setStoreCategories(List<Category> categories) {
        this.categories = categories;
    }

}
