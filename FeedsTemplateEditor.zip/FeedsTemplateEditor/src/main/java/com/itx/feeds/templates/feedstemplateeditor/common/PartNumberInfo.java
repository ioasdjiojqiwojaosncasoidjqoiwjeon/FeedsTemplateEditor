package com.itx.feeds.templates.feedstemplateeditor.common;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

// TODO: Auto-generated Javadoc
/**
 * The Class PartNumberInfo.
 *
 * @author LUISVPI
 */
public abstract class PartNumberInfo {

    /** The model. */
    protected final Integer model;

    /** The quality. */
    protected final Integer quality;

    /** The season. */
    protected final String season;

    /** The year. */
    protected final Integer year;

    /**
     * Instantiates a new part number info.
     *
     * @param model
     *            the model
     * @param quality
     *            the quality
     * @param season
     *            the season
     * @param year
     *            the year
     */
    protected PartNumberInfo(Integer model, Integer quality, String season, Integer year) {
        super();
        this.model = model;
        this.quality = quality;
        this.season = season;
        this.year = year;
    }

    /**
     * Gets the model.
     *
     * @return the model
     */
    public Integer getModel() {
        return model;
    }

    /**
     * Gets the model as string.
     *
     * @return the model as string
     */
    public String getModelAsString() {
        return String.format("%04d", getModel());
    }

    /**
     * Gets the quality.
     *
     * @return the quality
     */
    public Integer getQuality() {
        return quality;
    }

    /**
     * Gets the quality as string.
     *
     * @return the quality as string
     */
    public String getQualityAsString() {
        return String.format("%03d", getQuality());
    }

    /**
     * Gets the season.
     *
     * @return the season
     */
    public String getSeason() {
        return season;
    }

    /**
     * Gets the year.
     *
     * @return the year
     */
    public Integer getYear() {
        return year;
    }

    /**
     * To product part number.
     *
     * @return the string
     */
    public String toProductPartNumber() {
        return ProductPartNumberInfo.EMPTY_PARTNUMBER;
    }

    /**
     * Append color part number.
     *
     * @param color
     *            the color
     * @return the string
     */
    public String appendColorPartNumber(Integer color) {
        return ProductPartNumberInfo.EMPTY_PARTNUMBER.replace("-", String.format("%03d", color).concat("-"));
    }

    /**
     * @return string
     */
    @Override
    public final String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
