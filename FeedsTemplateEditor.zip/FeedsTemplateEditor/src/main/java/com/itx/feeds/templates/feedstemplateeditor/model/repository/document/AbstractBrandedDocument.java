package com.itx.feeds.templates.feedstemplateeditor.model.repository.document;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.AbstractDocumentData;

// TODO: Auto-generated Javadoc
/**
 * The Interface AbstractBrandedDocument.
 *
 * @param <E>
 *            the element type
 */
public interface AbstractBrandedDocument<E extends AbstractDocumentData> extends AbstractDocument<E> {

    /**
     * Gets the brand id.
     *
     * @return the brand id
     */
    Integer getBrandId();

    /**
     * Sets the brand id.
     *
     * @param BrandId
     *            the new brand id
     */
    void setBrandId(Integer BrandId);

}
