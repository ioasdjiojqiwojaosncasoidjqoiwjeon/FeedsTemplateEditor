package com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl;

import java.util.List;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl.MocaStoreData;


// TODO: Auto-generated Javadoc
/**
 * The Class MocaStore.
 *
 * @author LUISVPI
 */
public class MocaStore extends AbstractBrandedVersionedDocumentImpl<MocaStoreData> {

    /** The store id. */
    private Integer storeId;

    /** The product id. */
    private Integer productId;

    /** The moca i18n list. */
    private List<MocaI18n> mocaI18nList;

    /**
     * Instantiates a new moca store.
     *
     * @param data
     *            the data
     * @param feedsVersion
     *            the feeds version
     * @param brandId
     *            the brand id
     * @param storeId
     *            the store id
     * @param productId
     *            the product id
     * @param mocaI18nList
     *            the moca i18n list
     */
    public MocaStore(MocaStoreData data, long feedsVersion, Integer brandId, Integer storeId, Integer productId,
            List<MocaI18n> mocaI18nList) {
        super(data, feedsVersion, brandId);
        this.storeId = storeId;
        this.productId = productId;
        this.setMocaI18nList(mocaI18nList);
    }

    /**
     * Instantiates a new moca store.
     */
    public MocaStore() {
        super();
    }

    /**
     * Gets the store id.
     *
     * @return the store id
     */
    public Integer getStoreId() {
        return this.storeId;
    }

    /**
     * Sets the store id.
     *
     * @param storeId
     *            the new store id
     */
    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    /**
     * Gets the product id.
     *
     * @return the product id
     */
    public Integer getProductId() {
        return this.productId;
    }

    /**
     * Sets the product id.
     *
     * @param productId
     *            the new product id
     */
    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    /**
     * Gets the moca i18n list.
     *
     * @return the moca i18n list
     */
    public List<MocaI18n> getMocaI18nList() {
        return this.mocaI18nList;
    }

    /**
     * Sets the moca i18n list.
     *
     * @param mocaI18nList
     *            the new moca i18n list
     */
    public void setMocaI18nList(List<MocaI18n> mocaI18nList) {
        this.mocaI18nList = mocaI18nList;
    }

}
