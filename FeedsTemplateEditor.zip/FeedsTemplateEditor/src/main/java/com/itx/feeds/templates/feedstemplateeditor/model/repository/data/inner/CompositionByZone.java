package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class CompositionByZone.
 */
public class CompositionByZone {

    /** The part. */
    private String part;

    /** The zones. */
    private List<Zone> zones;

    /**
     * Instantiates a new composition by zone.
     *
     * @param part
     *            the part
     * @param zones
     *            the zones
     */
    public CompositionByZone(String part, List<Zone> zones) {
        super();
        this.part = part;
        this.zones = zones;
    }

    /**
     * Instantiates a new composition by zone.
     */
    public CompositionByZone() {
        super();
    }

    /**
     * Gets the part.
     *
     * @return the part
     */
    public String getPart() {
        return this.part;
    }

    /**
     * Sets the part.
     *
     * @param part
     *            the new part
     */
    public void setPart(String part) {
        this.part = part;
    }

    /**
     * Gets the zones.
     *
     * @return the zones
     */
    public List<Zone> getZones() {
        return this.zones;
    }

    /**
     * Sets the zones.
     *
     * @param zones
     *            the new zones
     */
    public void setZones(List<Zone> zones) {
        this.zones = zones;
    }

}
