package com.itx.feeds.templates.feedstemplateeditor;

public class StrategyEnum {

}
