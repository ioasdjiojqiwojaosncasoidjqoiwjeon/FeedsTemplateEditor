package com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl.ExportFileTypeConfigurationData;

// TODO: Auto-generated Javadoc
/**
 * The Class Configuration.
 */
public class ExportFileTypeConfiguration extends AbstractDocumentImpl<ExportFileTypeConfigurationData> {

    /** The exportType. */
    private String exportType;

    /** The brandId. */
    private Integer brandId;

    /**
     * Instantiates a new configuration.
     * 
     * @param data
     * @param exportType
     */
    public ExportFileTypeConfiguration(ExportFileTypeConfigurationData data, String exportType, Integer brandId) {
        super(data);
        this.exportType = exportType;
        this.brandId = brandId;
    }

    /**
     * Instantiates a new configuration.
     */
    public ExportFileTypeConfiguration() {
        super();
    }

    /**
     * Gets the exportType.
     *
     * @return the exportType
     */
    public String getExportType() {
        return this.exportType;
    }

    /**
     * Sets the exportType.
     *
     * @param exportType
     *            the new exportType
     */
    public void setExportType(String exportType) {
        this.exportType = exportType;
    }

    /**
     * @return the brandId
     */
    public Integer getBrandId() {
        return brandId;
    }

    /**
     * @param brandId
     *            the brandId to set
     */
    public void setBrandId(Integer brandId) {
        this.brandId = brandId;
    }

}
