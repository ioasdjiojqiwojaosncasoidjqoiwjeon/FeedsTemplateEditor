package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class XmediaLocation.
 */
public class XmediaLocation {

    /** The locations. */
    private List<Location> locations;

    /** The set. */
    private Integer set;

    /**
     * Instantiates a new xmedia location.
     *
     * @param locations
     *            the locations
     * @param set
     *            the set
     */
    public XmediaLocation(List<Location> locations, Integer set) {
        super();
        this.locations = locations;
        this.set = set;
    }

    /**
     * Instantiates a new xmedia location.
     */
    public XmediaLocation() {
        super();
    }

    /**
     * Gets the locations.
     *
     * @return the locations
     */
    public List<Location> getLocations() {
        return this.locations;
    }

    /**
     * Sets the locations.
     *
     * @param locations
     *            the new locations
     */
    public void setLocations(List<Location> locations) {
        this.locations = locations;
    }

    /**
     * Gets the sets the.
     *
     * @return the sets the
     */
    public Integer getSet() {
        return this.set;
    }

    /**
     * Sets the sets the.
     *
     * @param set
     *            the new sets the
     */
    public void setSet(Integer set) {
        this.set = set;
    }

}
