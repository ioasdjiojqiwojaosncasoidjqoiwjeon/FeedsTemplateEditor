package com.itx.feeds.templates.feedstemplateeditor.model.repository.document.impl;

import com.itx.feeds.templates.feedstemplateeditor.model.repository.data.impl.MocaI18nData;

// TODO: Auto-generated Javadoc
/**
 * The Class MocaI18n.
 */
public class MocaI18n extends AbstractBrandedVersionedDocumentImpl<MocaI18nData> {

    /** The store id. */
    private Integer storeId;

    /** The language id. */
    private Integer languageId;

    /** The product id. */
    private Integer productId;

    /**
     * Instantiates a new moca i18n.
     *
     * @param data
     *            the data
     * @param feedsVersion
     *            the feeds version
     * @param brandId
     *            the brand id
     * @param storeId
     *            the store id
     * @param languageId
     *            the language id
     * @param productId
     *            the product id
     */
    public MocaI18n(MocaI18nData data, long feedsVersion, Integer brandId, Integer storeId, Integer languageId,
            Integer productId) {
        super(data, feedsVersion, brandId);
        this.storeId = storeId;
        this.languageId = languageId;
        this.productId = productId;
    }

    /**
     * Instantiates a new moca i18n.
     */
    public MocaI18n() {
        super();
    }

    /**
     * Gets the store id.
     *
     * @return the store id
     */
    public Integer getStoreId() {
        return this.storeId;
    }

    /**
     * Sets the store id.
     *
     * @param storeId
     *            the new store id
     */
    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    /**
     * Gets the language id.
     *
     * @return the language id
     */
    public Integer getLanguageId() {
        return this.languageId;
    }

    /**
     * Sets the language id.
     *
     * @param languageId
     *            the new language id
     */
    public void setLanguageId(Integer languageId) {
        this.languageId = languageId;
    }

    /**
     * Gets the product id.
     *
     * @return the product id
     */
    public Integer getProductId() {
        return this.productId;
    }

    /**
     * Sets the product id.
     *
     * @param productId
     *            the new product id
     */
    public void setProductId(Integer productId) {
        this.productId = productId;
    }

}
