package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class Image.
 */
public class Image {

    /** The timestamp. */
    private String timestamp;

    /** The url. */
    private String url;

    /** The aux. */
    private List<String> aux;

    /** The type. */
    private List<String> type;

    /** The style. */
    private List<String> style;

    /**
     * Instantiates a new image.
     *
     * @param timestamp
     *            the timestamp
     * @param url
     *            the url
     * @param aux
     *            the aux
     * @param type
     *            the type
     * @param style
     *            the style
     */
    public Image(String timestamp, String url, List<String> aux, List<String> type, List<String> style) {
        super();
        this.timestamp = timestamp;
        this.url = url;
        this.aux = aux;
        this.type = type;
        this.style = style;
    }

    /**
     * Instantiates a new image.
     */
    public Image() {
        super();
    }

    /**
     * Gets the timestamp.
     *
     * @return the timestamp
     */
    public String getTimestamp() {
        return this.timestamp;
    }

    /**
     * Sets the timestamp.
     *
     * @param timestamp
     *            the new timestamp
     */
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * Gets the url.
     *
     * @return the url
     */
    public String getUrl() {
        return this.url;
    }

    /**
     * Sets the url.
     *
     * @param url
     *            the new url
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * Gets the aux.
     *
     * @return the aux
     */
    public List<String> getAux() {
        return this.aux;
    }

    /**
     * Sets the aux.
     *
     * @param aux
     *            the new aux
     */
    public void setAux(List<String> aux) {
        this.aux = aux;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public List<String> getType() {
        return this.type;
    }

    /**
     * Sets the type.
     *
     * @param type
     *            the new type
     */
    public void setType(List<String> type) {
        this.type = type;
    }

    /**
     * Gets the style.
     *
     * @return the style
     */
    public List<String> getStyle() {
        return this.style;
    }

    /**
     * Sets the style.
     *
     * @param style
     *            the new style
     */
    public void setStyle(List<String> style) {
        this.style = style;
    }

}
