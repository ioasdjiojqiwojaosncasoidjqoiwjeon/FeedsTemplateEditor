package com.itx.feeds.templates.feedstemplateeditor;

import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.util.Base64;

public enum FeedEnvironmentEnum {

	PRE("",
			basicAuth("", "")),
	PRO("", 
			basicAuth("", ""));

	private String host;

	private String basicAuth;

	private FeedEnvironmentEnum(String host, String basicAuth) {
		this.host = host;
		this.basicAuth = basicAuth;
	}

	public String getHost() {
		return this.host;
	}

	public String getBasicAuth() {
		return this.basicAuth;
	}
	
	private static String basicAuth(String username, String password) {
	    return "Basic " + Base64.getEncoder().encodeToString((username + ":" + password).getBytes());
	}

}
