package com.itx.feeds.templates.feedstemplateeditor.common;

import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

// TODO: Auto-generated Javadoc
/**
 * The Class PartNumberUtils.
 *
 * @author LUISVPI
 */
public class PartNumberUtils {

    /**
     * Instantiates a new part number utils.
     */
    private PartNumberUtils() {
    }

    /**
     * Color code as string.
     *
     * @param colorCode
     *            the color code
     * @return the string
     */
    public static String colorCodeAsString(Integer colorCode) {
        return StringUtils.leftPad(colorCode.toString(), 3, "0");
    }

    /**
     * Size code as string.
     *
     * @param sizeCode
     *            the size code
     * @return the string
     */
    public static String sizeCodeAsString(Integer sizeCode) {
        return StringUtils.leftPad(sizeCode.toString(), 2, "0");
    }

    /** The Constant TYPE_MODEL_QUALITY_COLOR_SIZE_PATTERN. */
    public static final Pattern TYPE_MODEL_QUALITY_COLOR_SIZE_PATTERN = Pattern
            .compile("(\\d)(\\d{4})(\\d{3})(\\d{3})(\\d{2})");

    /** The Constant TYPE_MODEL_QUALITY_COLOR_PATTERN. */
    public static final Pattern TYPE_MODEL_QUALITY_COLOR_PATTERN = Pattern.compile("(\\d)(\\d{4})(\\d{3})(\\d{3})");

    /** The Constant TYPE_MODEL_QUALITY_PATTERN. */
    public static final Pattern TYPE_MODEL_QUALITY_PATTERN = Pattern.compile("(\\d)(\\d{4})(\\d{3})");

    /**
     * Checks if is type model quality color size part number.
     *
     * @param partNumber
     *            the part number
     * @return true, if is type model quality color size part number
     */
    public static boolean isTypeModelQualityColorSizePartNumber(String partNumber) {
        return TYPE_MODEL_QUALITY_COLOR_SIZE_PATTERN.matcher(partNumber).matches();
    }

    /**
     * Checks if is type model quality color part number.
     *
     * @param partNumber
     *            the part number
     * @return true, if is type model quality color part number
     */
    public static boolean isTypeModelQualityColorPartNumber(String partNumber) {
        return TYPE_MODEL_QUALITY_COLOR_PATTERN.matcher(partNumber).matches();
    }

    /**
     * Checks if is type model quality part number.
     *
     * @param partNumber
     *            the part number
     * @return true, if is type model quality part number
     */
    public static boolean isTypeModelQualityPartNumber(String partNumber) {
        return TYPE_MODEL_QUALITY_PATTERN.matcher(partNumber).matches();
    }

    /**
     * Gets the color code as string from part number.
     *
     * @param brandId
     *            the brand id
     * @param partNumber
     *            the part number
     * @return the color code as string from part number
     */
    public static String getColorCodeAsStringFromPartNumber(int brandId, String partNumber) {
        Integer colorCode = getColorFromPartnumber(brandId, partNumber);
        if (colorCode == null) {
            return null;
        }
        return colorCodeAsString(colorCode);
    }

    /**
     * Gets the size code as string from part number.
     *
     * @param partNumber
     *            the part number
     * @return the size code as string from part number
     */
    public static String getSizeCodeAsStringFromPartNumber(String partNumber) {
        Integer sizeCode = getSizeFromPartnumber(partNumber);
        if (sizeCode == null) {
            return null;
        }
        return sizeCodeAsString(sizeCode);
    }

    /**
     * Gets the color from partnumber.
     *
     * @param brandId
     *            the brand id
     * @param partNumber
     *            the part number
     * @return the color from partnumber
     */
    public static Integer getColorFromPartnumber(int brandId, String partNumber) {
        ColorPartNumberInfo c = ColorPartNumberInfo.build(partNumber);
        if (c != null) {
            return c.getColor();
        }
        SkuPartNumberInfo s = SkuPartNumberInfo.build(partNumber);
        if (s != null) {
            return s.getColor();
        }

        return null;
    }

    /**
     * Gets the size from partnumber.
     *
     * @param partNumber
     *            the part number
     * @return the size from partnumber
     */
    public static Integer getSizeFromPartnumber(String partNumber) {

        SkuPartNumberInfo s = SkuPartNumberInfo.build(partNumber);
        if (s != null) {
            return s.getColor();
        }
        return null;
    }

    /**
     * @param partNumber
     * @return String with the color
     */
    public static String getMocacoPartnumber(String partNumber) {

        SkuPartNumberInfo s = SkuPartNumberInfo.build(partNumber);
        if (s != null) {
            return s.toColorPartNumber();
        }
        return "";
    }

}
