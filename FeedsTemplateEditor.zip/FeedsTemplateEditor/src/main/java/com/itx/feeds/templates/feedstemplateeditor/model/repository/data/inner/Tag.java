package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class Tag.
 */
public class Tag {

    /** The category. */
    private MocaI18nCategory category;

    /** The attachments. */
    private List<Attachment> attachments;

    /**
     * Instantiates a new tag.
     *
     * @param category
     *            the category
     * @param attachments
     *            the attachments
     */
    public Tag(MocaI18nCategory category, List<Attachment> attachments) {
        super();
        this.category = category;
        this.attachments = attachments;
    }

    /**
     * Instantiates a new tag.
     */
    public Tag() {
        super();
    }

    /**
     * Gets the category.
     *
     * @return the category
     */
    public MocaI18nCategory getCategory() {
        return this.category;
    }

    /**
     * Sets the category.
     *
     * @param category
     *            the new category
     */
    public void setCategory(MocaI18nCategory category) {
        this.category = category;
    }

    /**
     * Gets the attachments.
     *
     * @return the attachments
     */
    public List<Attachment> getAttachments() {
        return this.attachments;
    }

    /**
     * Sets the attachments.
     *
     * @param attachments
     *            the new attachments
     */
    public void setAttachments(List<Attachment> attachments) {
        this.attachments = attachments;
    }

}
