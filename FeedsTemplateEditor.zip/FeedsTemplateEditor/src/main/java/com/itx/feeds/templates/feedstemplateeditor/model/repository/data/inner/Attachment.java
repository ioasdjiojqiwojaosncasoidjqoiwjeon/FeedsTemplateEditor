package com.itx.feeds.templates.feedstemplateeditor.model.repository.data.inner;

// TODO: Auto-generated Javadoc
/**
 * The Class Attachment.
 */
public class Attachment {

    /** The id. */
    private String id;

    /** The name. */
    private String name;

    /** The path. */
    private String path;

    /** The type. */
    private String type;

    /**
     * Instantiates a new attachment.
     *
     * @param id
     *            the id
     * @param name
     *            the name
     * @param path
     *            the path
     * @param type
     *            the type
     */
    public Attachment(String id, String name, String path, String type) {
        super();
        this.id = id;
        this.name = name;
        this.path = path;
        this.type = type;
    }

    /**
     * Instantiates a new attachment.
     */
    public Attachment() {
        super();
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public String getId() {
        return this.id;
    }

    /**
     * Sets the id.
     *
     * @param id
     *            the new id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the name.
     *
     * @param name
     *            the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the path.
     *
     * @return the path
     */
    public String getPath() {
        return this.path;
    }

    /**
     * Sets the path.
     *
     * @param path
     *            the new path
     */
    public void setPath(String path) {
        this.path = path;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
        return this.type;
    }

    /**
     * Sets the type.
     *
     * @param type
     *            the new type
     */
    public void setType(String type) {
        this.type = type;
    }

}
